package cg;

import java.util.*;
import java.util.function.IntSupplier;

/**
 * PipelineContract -- behavior-neutral ordering guard for PHPCGFactory.newInstance().
 *
 * WHY: the 44-pass pipeline communicates through shared static fields; the ordering
 * constraints (49 derived from a transitive read/write scan of the current source)
 * exist only as line order and comments. This class makes them checked.
 *
 * SAFETY MODEL (matches the checkpoint-caution decision):
 *   - Inert unless WP_PIPELINE_CONTRACT is set. Zero cost, zero output otherwise.
 *   - WP_PIPELINE_CONTRACT=warn  : validate + print violations to stderr, never throw.
 *   - WP_PIPELINE_CONTRACT=strict: throw IllegalStateException on violation
 *     (for CI only -- never default, so a contract bug cannot break analysis runs).
 *
 * WHAT IT CHECKS at each step(pass):
 *   1. ORDER    : every baked-in (before -> after) constraint whose 'after' is this
 *                 pass has already seen its 'before' executed.
 *   2. VACUITY  : every field this pass READS per the contract is non-empty when a
 *                 prior pass should have populated it -- this is the entryPriv-class
 *                 bug ("the receiver check had never fired") made loud.
 *   3. FREEZE   : fields declared frozen (call2mtd after dispatch augmentation) do
 *                 not change size afterwards -- catches a mis-split writing late.
 *   4. DRIFT    : any registered field whose size changed during a pass that the
 *                 contract says does NOT write it => the contract (or a helper) is
 *                 out of date; reported so the table never rots silently.
 *
 * The pass list and constraints below are GENERATED from the source scan of
 * PHPCGFactory (2026-08-15). Regenerate when passes are added/moved.
 */
public final class PipelineContract {

	private static final String MODE = System.getenv("WP_PIPELINE_CONTRACT"); // null | "warn" | "strict"
	public static boolean enabled() { return MODE != null && !MODE.isEmpty(); }

	// ---- generated data ----
	private static final String[] PASSES = { "init", "createFunctionCallEdges", "createConstructorCallEdges", "createStaticMethodCallEdges", "collectWpdbAliases", "collectWpdbAccessorMethods", "classifyUserSanitizers", "registerInferredSanitizerNodes", "computeLiteralOnlyVars", "demoteAllUnquotedEscSql", "createNonStaticMethodCallEdges", "resolveCallableDispatch", "resolveHookDispatch", "seedForeachOverSource", "seedDynKeyArrayWrite", "forwardInlineSourceArgs", "augmentStaticDispatchEdges", "augmentInstanceDispatchEdges", "dumpCallGraph", "dumpCallResolutionStats", "dumpPropertyReceiverStats", "dumpSetterStats", "resolveStoredReadWrappers", "filterProvablySafeXssSinks", "seedQueryVarsSources", "detectQueryWrappers", "buildReturnSafetySummaries", "suppressWhitelistGuardedSources", "seedRawInputSources", "seedStoredTaintSources", "detectAdditionalSinks", "seedFileUploadSources", "seedWordPressEntryPoints", "seedRestRequestSources", "seedRestArrayAccess", "seedBlockRegistrations", "seedElementorWidgets", "seedWidgetQueryVarTemplates", "seedSelfContainedHandlers", "resolveFileScopeIncludeProvenance", "auditAccessControl", "emitControlReachabilityCandidates", "dumpSummaries", "reset" };
	private static final String[][] CONSTRAINTS = {
		c("createConstructorCallEdges", "createStaticMethodCallEdges", "ch2prt"),
		c("createStaticMethodCallEdges", "collectWpdbAliases", "sources"),
		c("createStaticMethodCallEdges", "collectWpdbAccessorMethods", "sources"),
		c("createStaticMethodCallEdges", "classifyUserSanitizers", "sources"),
		c("createStaticMethodCallEdges", "registerInferredSanitizerNodes", "sources"),
		c("createStaticMethodCallEdges", "demoteAllUnquotedEscSql", "sources"),
		c("createConstructorCallEdges", "createNonStaticMethodCallEdges", "ch2prt"),
		c("createNonStaticMethodCallEdges", "resolveCallableDispatch", "allFunc"),
		c("createNonStaticMethodCallEdges", "resolveHookDispatch", "allFunc"),
		c("resolveCallableDispatch", "resolveHookDispatch", "ch2prt"),
		c("resolveCallableDispatch", "resolveHookDispatch", "sources"),
		c("resolveHookDispatch", "forwardInlineSourceArgs", "call2mtd"),
		c("resolveCallableDispatch", "augmentStaticDispatchEdges", "ch2prt"),
		c("forwardInlineSourceArgs", "augmentStaticDispatchEdges", "sources"),
		c("resolveCallableDispatch", "augmentInstanceDispatchEdges", "ch2prt"),
		c("forwardInlineSourceArgs", "augmentInstanceDispatchEdges", "sources"),
		c("augmentInstanceDispatchEdges", "dumpCallGraph", "call2mtd"),
		c("forwardInlineSourceArgs", "dumpCallGraph", "sources"),
		c("augmentInstanceDispatchEdges", "dumpCallResolutionStats", "call2mtd"),
		c("forwardInlineSourceArgs", "dumpPropertyReceiverStats", "sources"),
		c("createNonStaticMethodCallEdges", "dumpSetterStats", "sinks"),
		c("forwardInlineSourceArgs", "dumpSetterStats", "sources"),
		c("augmentInstanceDispatchEdges", "resolveStoredReadWrappers", "call2mtd"),
		c("forwardInlineSourceArgs", "filterProvablySafeXssSinks", "sources"),
		c("resolveCallableDispatch", "detectQueryWrappers", "ch2prt"),
		c("seedQueryVarsSources", "detectQueryWrappers", "sources"),
		c("detectQueryWrappers", "buildReturnSafetySummaries", "call2mtd"),
		c("detectQueryWrappers", "seedStoredTaintSources", "call2mtd"),
		c("detectQueryWrappers", "seedStoredTaintSources", "retArbitraryFids"),
		c("detectQueryWrappers", "detectAdditionalSinks", "call2mtd"),
		c("seedStoredTaintSources", "detectAdditionalSinks", "sources"),
		c("seedWordPressEntryPoints", "seedRestRequestSources", "entryPriv"),
		c("seedWordPressEntryPoints", "seedRestArrayAccess", "entryPriv"),
		c("detectQueryWrappers", "seedElementorWidgets", "call2mtd"),
		c("createNonStaticMethodCallEdges", "seedSelfContainedHandlers", "allFunc"),
		c("seedWidgetQueryVarTemplates", "seedSelfContainedHandlers", "sources"),
		c("detectQueryWrappers", "resolveFileScopeIncludeProvenance", "call2mtd"),
		c("seedElementorWidgets", "resolveFileScopeIncludeProvenance", "entryPriv"),
		c("resolveCallableDispatch", "auditAccessControl", "ch2prt"),
		c("seedElementorWidgets", "auditAccessControl", "entryPriv"),
		c("seedWidgetQueryVarTemplates", "auditAccessControl", "sources"),
		c("auditAccessControl", "emitControlReachabilityCandidates", "call2mtd"),
		c("seedElementorWidgets", "emitControlReachabilityCandidates", "entryPriv"),
		c("seedElementorWidgets", "emitControlReachabilityCandidates", "sinkClass"),
		c("seedWidgetQueryVarTemplates", "emitControlReachabilityCandidates", "sources"),
		c("auditAccessControl", "dumpSummaries", "retArbitraryFids"),
		c("auditAccessControl", "dumpSummaries", "sinks"),
		c("seedWidgetQueryVarTemplates", "dumpSummaries", "sources"),
		c("seedSelfContainedHandlers", "dumpSummaries", "topFunIds")
	};
	private static String[] c(String b, String a, String via) { return new String[]{b, a, via}; }

	// reads-per-pass (for vacuity), generated: pass -> fields it reads but does not write
	private static final Map<String, List<String>> READS = new HashMap<>();
	static {
		READS.put("init", Arrays.asList("sources"));
		READS.put("createFunctionCallEdges", Arrays.asList("classDef", "path2callee"));
		READS.put("createConstructorCallEdges", Arrays.asList("classDef", "path2callee"));
		READS.put("createStaticMethodCallEdges", Arrays.asList("ch2prt", "classDef", "path2callee"));
		READS.put("collectWpdbAliases", Arrays.asList("sources"));
		READS.put("collectWpdbAccessorMethods", Arrays.asList("sources"));
		READS.put("classifyUserSanitizers", Arrays.asList("sources"));
		READS.put("registerInferredSanitizerNodes", Arrays.asList("sources"));
		READS.put("demoteAllUnquotedEscSql", Arrays.asList("sources"));
		READS.put("createNonStaticMethodCallEdges", Arrays.asList("ch2prt", "classDef", "path2callee"));
		READS.put("resolveCallableDispatch", Arrays.asList("allFunc", "classDef"));
		READS.put("resolveHookDispatch", Arrays.asList("allFunc", "ch2prt", "sources"));
		READS.put("forwardInlineSourceArgs", Arrays.asList("call2mtd"));
		READS.put("augmentStaticDispatchEdges", Arrays.asList("ch2prt", "classDef", "sources"));
		READS.put("augmentInstanceDispatchEdges", Arrays.asList("ch2prt", "classDef", "sources"));
		READS.put("dumpCallGraph", Arrays.asList("call2mtd", "sources"));
		READS.put("dumpCallResolutionStats", Arrays.asList("call2mtd"));
		READS.put("dumpPropertyReceiverStats", Arrays.asList("sources"));
		READS.put("dumpSetterStats", Arrays.asList("sinks", "sources"));
		READS.put("resolveStoredReadWrappers", Arrays.asList("call2mtd"));
		READS.put("filterProvablySafeXssSinks", Arrays.asList("sources"));
		READS.put("detectQueryWrappers", Arrays.asList("ch2prt", "classDef", "sources"));
		READS.put("buildReturnSafetySummaries", Arrays.asList("call2mtd"));
		READS.put("seedStoredTaintSources", Arrays.asList("call2mtd", "retArbitraryFids"));
		READS.put("detectAdditionalSinks", Arrays.asList("call2mtd", "sources"));
		READS.put("seedRestRequestSources", Arrays.asList("entryPriv"));
		READS.put("seedRestArrayAccess", Arrays.asList("entryPriv"));
		READS.put("seedElementorWidgets", Arrays.asList("call2mtd", "classDef"));
		READS.put("seedSelfContainedHandlers", Arrays.asList("allFunc", "sources"));
		READS.put("resolveFileScopeIncludeProvenance", Arrays.asList("call2mtd", "entryPriv"));
		READS.put("auditAccessControl", Arrays.asList("ch2prt", "entryPriv", "sources"));
		READS.put("emitControlReachabilityCandidates", Arrays.asList("call2mtd", "entryPriv", "sinkClass", "sources"));
		READS.put("dumpSummaries", Arrays.asList("retArbitraryFids", "sinks", "sources", "topFunIds"));
	}
	private static final Map<String, List<String>> WRITES_ALL = new HashMap<>();
	static {
		WRITES_ALL.put("init", Arrays.asList("ch2prt", "retCls", "topFunIds", "retCls"));
		WRITES_ALL.put("createFunctionCallEdges", Arrays.asList("allFunc", "call2mtd", "callee2caller", "ch2prt", "functionCalls", "mtd2mtd", "retCls", "sinkClass", "sinks", "sources", "sqlSanitizers", "topFunIds", "allFunc", "call2mtd", "ch2prt", "functionCalls", "retCls", "sources"));
		WRITES_ALL.put("createConstructorCallEdges", Arrays.asList("allFunc", "call2mtd", "callee2caller", "ch2prt", "functionCalls", "mtd2mtd", "retCls", "sinks", "sources", "sqlSanitizers", "topFunIds", "call2mtd", "ch2prt", "retCls", "sources"));
		WRITES_ALL.put("createStaticMethodCallEdges", Arrays.asList("allFunc", "call2mtd", "callee2caller", "functionCalls", "mtd2mtd", "retCls", "sinks", "sources", "sqlSanitizers", "topFunIds", "call2mtd", "retCls", "sources"));
		WRITES_ALL.put("registerInferredSanitizerNodes", Arrays.asList("sqlSanitizers"));
		WRITES_ALL.put("demoteAllUnquotedEscSql", Arrays.asList("sqlSanitizers"));
		WRITES_ALL.put("createNonStaticMethodCallEdges", Arrays.asList("allFunc", "call2mtd", "callee2caller", "functionCalls", "mtd2mtd", "retCls", "sinks", "sources", "sqlSanitizers", "topFunIds", "call2mtd", "retCls", "sources"));
		WRITES_ALL.put("resolveCallableDispatch", Arrays.asList("call2mtd", "callee2caller", "ch2prt", "derivedProvenanceNodes", "functionCalls", "hookParamSourceNodes", "mtd2mtd", "promotedParamEvidence", "retCls", "sources", "topFunIds", "call2mtd", "ch2prt", "derivedProvenanceNodes", "promotedParamEvidence", "retCls"));
		WRITES_ALL.put("resolveHookDispatch", Arrays.asList("call2mtd", "call2mtd"));
		WRITES_ALL.put("seedForeachOverSource", Arrays.asList("sources", "sources"));
		WRITES_ALL.put("seedDynKeyArrayWrite", Arrays.asList("sources", "sources"));
		WRITES_ALL.put("forwardInlineSourceArgs", Arrays.asList("derivedProvenanceNodes", "hookParamSourceNodes", "promotedParamEvidence", "sources", "derivedProvenanceNodes", "promotedParamEvidence", "sources"));
		WRITES_ALL.put("augmentStaticDispatchEdges", Arrays.asList("call2mtd", "call2mtd"));
		WRITES_ALL.put("augmentInstanceDispatchEdges", Arrays.asList("call2mtd", "call2mtd"));
		WRITES_ALL.put("filterProvablySafeXssSinks", Arrays.asList("sinkClass", "sinks", "xssEscaperMatched", "xsssinks", "sinkClass"));
		WRITES_ALL.put("seedQueryVarsSources", Arrays.asList("sources", "sources"));
		WRITES_ALL.put("detectQueryWrappers", Arrays.asList("call2mtd", "retArbitraryFids", "sinks", "call2mtd", "retArbitraryFids", "sinks"));
		WRITES_ALL.put("suppressWhitelistGuardedSources", Arrays.asList("sources", "sources"));
		WRITES_ALL.put("seedRawInputSources", Arrays.asList("sources", "sources"));
		WRITES_ALL.put("seedStoredTaintSources", Arrays.asList("sources", "sources"));
		WRITES_ALL.put("detectAdditionalSinks", Arrays.asList("sinkClass", "sinks"));
		WRITES_ALL.put("seedFileUploadSources", Arrays.asList("sources", "sources"));
		WRITES_ALL.put("seedWordPressEntryPoints", Arrays.asList("entryPriv", "hookParamSourceNodes", "sinkClass", "sinks", "sources", "topFunIds", "sources"));
		WRITES_ALL.put("seedRestRequestSources", Arrays.asList("sources", "sources"));
		WRITES_ALL.put("seedRestArrayAccess", Arrays.asList("sources", "sources"));
		WRITES_ALL.put("seedBlockRegistrations", Arrays.asList("entryPriv", "sinkClass", "sinks", "sources", "topFunIds", "sources"));
		WRITES_ALL.put("seedElementorWidgets", Arrays.asList("entryPriv", "sinkClass", "sinks", "sources", "topFunIds", "sinks", "sources"));
		WRITES_ALL.put("seedWidgetQueryVarTemplates", Arrays.asList("sources", "sources"));
		WRITES_ALL.put("seedSelfContainedHandlers", Arrays.asList("topFunIds", "topFunIds"));
		WRITES_ALL.put("auditAccessControl", Arrays.asList("call2mtd", "retArbitraryFids", "sinks", "call2mtd", "retArbitraryFids", "sinks"));
		WRITES_ALL.put("dumpSummaries", Arrays.asList("call2mtd", "call2mtd"));
		WRITES_ALL.put("reset", Arrays.asList("call2mtd", "callee2caller", "functionCalls", "mtd2mtd", "call2mtd"));
	}

	// ---- runtime state ----
	private static final Map<String, IntSupplier> probes = new LinkedHashMap<>();
	private static final Map<String, Integer> lastSize = new HashMap<>();
	private static final Set<String> executed = new LinkedHashSet<>();
	private static final Map<String, Integer> frozenAt = new HashMap<>();
	private static String currentPass = null;
	private static int violations = 0;

	/** Register a size probe for a shared field, e.g. probe("call2mtd", () -> call2mtd.size()). */
	public static void probe(String field, IntSupplier size) {
		if (!enabled()) return;
		probes.put(field, size);
	}

	/** Declare a field frozen from this point on (size must not change). */
	public static void freeze(String field) {
		if (!enabled()) return;
		IntSupplier p = probes.get(field);
		if (p != null) frozenAt.put(field, p.getAsInt());
	}

	/** Call immediately BEFORE each pipeline pass. Additive; makes no state changes. */
	public static void step(String pass) {
		if (!enabled()) return;
		closePrevious();
		currentPass = pass;
		// 1. ORDER
		for (String[] c : CONSTRAINTS)
			if (c[1].equals(pass) && !executed.contains(c[0]))
				report("ORDER", pass + " requires " + c[0] + " first (via " + c[2] + ")");
		// 2. VACUITY
		List<String> reads = READS.get(pass);
		if (reads != null) for (String f : reads) {
			IntSupplier p = probes.get(f);
			if (p != null && p.getAsInt() == 0 && somePriorPassWrites(f))
				report("VACUITY", pass + " reads '" + f + "' which is EMPTY -- its check may never fire (entryPriv-class bug)");
		}
		snapshot();
	}

	/** Call once after the last pass. */
	public static void finish() {
		if (!enabled()) return;
		closePrevious();
		System.err.println("WP_CONTRACT summary: " + executed.size() + " passes, " + violations + " violation(s)");
		if (violations > 0 && "strict".equals(MODE))
			throw new IllegalStateException("PipelineContract: " + violations + " violation(s); see WP_CONTRACT stderr lines");
	}

	private static void closePrevious() {
		if (currentPass == null) return;
		// 3. FREEZE + 4. DRIFT for the pass that just ran
		for (Map.Entry<String, IntSupplier> e : probes.entrySet()) {
			int now = e.getValue().getAsInt();
			Integer before = lastSize.get(e.getKey());
			if (before != null && now != before) {
				Integer fsz = frozenAt.get(e.getKey());
				if (fsz != null)
					report("FREEZE", currentPass + " changed frozen field '" + e.getKey() + "' (" + before + " -> " + now + ")");
				List<String> declared = WRITES_ALL.get(currentPass);
				if (declared == null || !declared.contains(e.getKey()))
					report("DRIFT", currentPass + " changed '" + e.getKey() + "' (" + before + " -> " + now + ") but contract says it does not write it -- regenerate the contract");
			}
		}
		executed.add(currentPass);
		currentPass = null;
	}

	private static boolean somePriorPassWrites(String field) {
		for (String p : executed) {
			List<String> w = WRITES_ALL.get(p);
			if (w != null && w.contains(field)) return true;
		}
		return false;
	}

	private static void snapshot() {
		for (Map.Entry<String, IntSupplier> e : probes.entrySet())
			lastSize.put(e.getKey(), e.getValue().getAsInt());
	}

	private static void report(String kind, String msg) {
		violations++;
		System.err.println("WP_CONTRACT " + kind + ": " + msg);
	}

	private PipelineContract() {}
}
