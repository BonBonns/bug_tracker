// Simulates the pipeline to prove the contract fires correctly:
//  correct prefix        -> no violations
//  entryPriv read w/o writer having run -> VACUITY   (the historical bug)
//  frozen call2mtd mutated late          -> FREEZE
//  undeclared write                      -> DRIFT
import cg.PipelineContract;
import java.util.*;

public class TestContract {
    static Set<Long> call2mtd = new HashSet<>();
    static Map<Long,String> entryPriv = new HashMap<>();
    static Set<Long> sources = new HashSet<>();
    public static void main(String[] a) {
        PipelineContract.probe("call2mtd", () -> call2mtd.size());
        PipelineContract.probe("entryPriv", () -> entryPriv.size());
        PipelineContract.probe("sources", () -> sources.size());

        // ---- correct-order prefix: should be silent ----
        PipelineContract.step("createFunctionCallEdges"); call2mtd.add(1L);
        PipelineContract.step("createConstructorCallEdges");
        PipelineContract.step("createStaticMethodCallEdges"); sources.add(5L);
        PipelineContract.step("createNonStaticMethodCallEdges"); call2mtd.add(2L);
        PipelineContract.step("resolveCallableDispatch");
        PipelineContract.step("resolveHookDispatch"); call2mtd.add(3L);
        PipelineContract.step("forwardInlineSourceArgs"); sources.add(6L);
        PipelineContract.step("augmentStaticDispatchEdges");
        PipelineContract.step("augmentInstanceDispatchEdges");
        PipelineContract.freeze("call2mtd");

        // ---- VACUITY: reads entryPriv; none of its writer passes have run ----
        PipelineContract.step("seedRestRequestSources");
        sources.add(7L);   // also a DRIFT probe: contract says this pass writes sources, so no drift here

        // ---- FREEZE: mutate frozen call2mtd inside a later pass ----
        PipelineContract.step("detectQueryWrappers"); call2mtd.add(99L);

        // ---- DRIFT: a pass that per contract does NOT write entryPriv writes it ----
        PipelineContract.step("dumpSummaries"); entryPriv.put(7L, "oops");

        PipelineContract.finish();
    }
}
