	public static CG newInstance() {
		CG cg = new CG();
		// ---- PipelineContract probes (inert unless WP_PIPELINE_CONTRACT is set) ----
		PipelineContract.probe("call2mtd",   () -> call2mtd.size());
		PipelineContract.probe("sinks",      () -> sinks.size());
		PipelineContract.probe("sources",    () -> PHPCSVEdgeInterpreter.sources.size());
		PipelineContract.probe("entryPriv",  () -> entryPriv.size());
		PipelineContract.probe("topFunIds",  () -> topFunIds.size());
		PipelineContract.probe("sqlSanitizers", () -> tools.php.ast2cpg.PHPCSVEdgeInterpreter.sqlSanitizers.size());
		PipelineContract.probe("retArbitraryFids", () -> retArbitraryFids.size());
		PipelineContract.probe("hookParamSourceNodes", () -> hookParamSourceNodes.size());
		PipelineContract.probe("path2callee", () -> path2callee.size());
		PipelineContract.probe("allFunc",    () -> allFunc.size());
		
		init();
		
		//createSpiderEdges(cg);
		System.err.println("@");
		PipelineContract.step("createFunctionCallEdges");
		createFunctionCallEdges(cg);
		System.err.println("@@");
		PipelineContract.step("createConstructorCallEdges");
		createConstructorCallEdges(cg);
		System.err.println("@@@");
		PipelineContract.step("createStaticMethodCallEdges");
		createStaticMethodCallEdges(cg);
		System.err.println("@@@@");
		// Collect $wpdb aliases ($_db = $wpdb, $this->wpdb = $wpdb) BEFORE non-static
		// method-call processing, because that pass is where $wpdb sinks are detected
		// and it must recognize alias receivers too.
		PipelineContract.step("collectWpdbAliases");
		collectWpdbAliases();
		PipelineContract.step("collectWpdbAccessorMethods");
		collectWpdbAccessorMethods();
		// Prove-before-recognize inference of user-defined sanitizers: integer sanitizers
		// (ctype_digit/intval-style) and quote-escapers (addslashes/strtr-map). Must run after
		// parsing populated the AST/sqlSanitizers and BEFORE the esc_sql demotion, so inferred
		// escaper calls registered into sqlSanitizers are subject to the unquoted-context drop.
		PipelineContract.step("classifyUserSanitizers");
		classifyUserSanitizers();
		PipelineContract.step("registerInferredSanitizerNodes");
		registerInferredSanitizerNodes();
		PipelineContract.step("computeLiteralOnlyVars");
		computeLiteralOnlyVars();       // resolve constant-bearing locals so the XSS suppressor can credit them
		// Context-sensitive esc_sql: drop unquoted inline esc_sql calls from the SQL
		// sanitizer set so their taint is reported (CVE-2021-24340 class). Must run
		// after parsing populated sqlSanitizers and before the taint analysis consumes it.
		PipelineContract.step("demoteAllUnquotedEscSql");
		demoteAllUnquotedEscSql();
		PipelineContract.step("createNonStaticMethodCallEdges");
		createNonStaticMethodCallEdges(cg);
		PipelineContract.step("resolveCallableDispatch");
		resolveCallableDispatch();   // model call_user_func / array-callable dispatch (recall fix)
		PipelineContract.step("resolveHookDispatch");
		resolveHookDispatch();       // model do_action/apply_filters -> registered handler dispatch (recall fix)
		PipelineContract.step("seedForeachOverSource");
		seedForeachOverSource();     // foreach($SOURCE as $v): taint iteration vars (CVE-2022-0513 class)
		PipelineContract.step("seedDynKeyArrayWrite");
		seedDynKeyArrayWrite();      // $base[$dynKey]=<tainted>: taint base array (CVE-2022-0513 remaining link)
		PipelineContract.step("forwardInlineSourceArgs");
		forwardInlineSourceArgs();   // seed callee params from inline-source call args (recall fix)
		// Dispatch augmentation must run for EVERY taint class, not only when the ACL/CSRF/IDOR/
		// OPTIONS_WRITE audit or XSS_ONLY happens to be on. Both are idempotent.
		PipelineContract.step("augmentStaticDispatchEdges");
		augmentStaticDispatchEdges();
		PipelineContract.step("augmentInstanceDispatchEdges");
		augmentInstanceDispatchEdges();
		PipelineContract.freeze("call2mtd");   // dispatch model complete; later writes are contract violations
		if( System.getenv("WP_DECLARATIVE_DISPATCH") != null ) scanDeclarativeDispatchCandidates();
		PipelineContract.step("dumpCallGraph");
		dumpCallGraph();             // export resolved call2mtd for the adjudicator (node-accurate chain)
		PipelineContract.step("dumpCallResolutionStats");
		dumpCallResolutionStats();   // WP_CALL_RESOLUTION_STATS=1: M/N call2mtd resolution rate by call kind
		PipelineContract.step("dumpPropertyReceiverStats");
		dumpPropertyReceiverStats(); // WP_PROP_STATS=1: cross-object over-taint surface of Class::property
		PipelineContract.step("dumpSetterStats");
		dumpSetterStats();           // WP_SETTER_STATS=1: setter-propagation ($o->field=$v) surface
		// Resolve setting-getter wrappers to their backing stored key BEFORE the XSS suppressor runs, so
		// an output of a wrapper (e.g. echo get_close_text()) is credited as a stored read and kept as a
		// sink. Runs after call-edge creation so wrapper-of-wrapper chains resolve. Inert unless stored-
		// taint is on, so the oracle runs (stored-taint off) are unaffected by this reordering.
		PipelineContract.step("resolveStoredReadWrappers");
		resolveStoredReadWrappers(buildVarAssigns());
		PipelineContract.step("filterProvablySafeXssSinks");
		filterProvablySafeXssSinks();   // drop echo/print sinks fully escaped at output (all modes)
		// Model thin DB query-wrappers as sinks so taint passed to them is reported.
		// Runs after base $wpdb sinks are known and before seeding, so a handler that
		// contains a wrapper call is also picked up as a self-contained entry point.
		PipelineContract.step("seedQueryVarsSources");
		seedQueryVarsSources();
		PipelineContract.step("detectQueryWrappers");
		detectQueryWrappers();
		PipelineContract.step("buildReturnSafetySummaries");
		buildReturnSafetySummaries();   // echo-of-call precision: classify callee returns (needs call2mtd + retArbitrary built)
		PipelineContract.step("suppressWhitelistGuardedSources");
		suppressWhitelistGuardedSources();   // FIX 35: in_array() whitelist guards
		System.err.println("@@@@@");

		// WP REST handlers receive user input via $request->get_param()/get_params()/etc.,
		// not superglobals. Model that getter family as taint sources so REST routes seeded
		// below (esp. permissive permission_callbacks in public mode) actually propagate taint.
		// MOVED (2026-08-08, alongside its fix): must run AFTER seedWordPressEntryPoints() below,
		// since it now requires entryPriv (populated there) to confirm the receiver is really a
		// REST callback's own first parameter -- it previously ran here, before entryPriv
		// existed, which is part of why the receiver check had never been added.
		PipelineContract.step("seedRawInputSources");
		seedRawInputSources();
		PipelineContract.step("seedStoredTaintSources");
		seedStoredTaintSources();

		// Extended sink classes (object injection, SSRF, LFI/RFI, RCE, file access).
		PipelineContract.step("detectAdditionalSinks");
		detectAdditionalSinks();
		// File-upload sources ($_FILES[*][name|type]); pairs with the file-access sinks above.
		PipelineContract.step("seedFileUploadSources");
		seedFileUploadSources();

		// WORDPRESS ENTRY-POINT SEEDING: WordPress invokes plugin handlers through hooks
		// (add_action('wp_ajax_*', cb), register_rest_route(..., cb)), so those handler
		// functions/methods are never called from top-level PHP and TChecker would never
		// analyze them. Stock TChecker learns entry points from an XDebug profiler trace;
		// this is the WordPress analogue. We scan for hook registrations, resolve the
		// callback to its definition, and register it as an analysis root (topFunIds) so
		// taint analysis starts from WordPress request handlers.
		PipelineContract.step("seedWordPressEntryPoints");
		seedWordPressEntryPoints();
		PipelineContract.step("seedRestRequestSources");
		seedRestRequestSources();    // moved here: needs entryPriv (populated above) for the receiver check
		PipelineContract.step("seedRestArrayAccess");
		seedRestArrayAccess();       // $request['key'] array-access as REST source (CVE-2022-45808 class)
		PipelineContract.step("seedBlockRegistrations");
		seedBlockRegistrations();
		PipelineContract.step("seedElementorWidgets");
		seedElementorWidgets();
		PipelineContract.step("seedWidgetQueryVarTemplates");
		seedWidgetQueryVarTemplates();   // WP-core the_widget->set_query_var->load_template(extract) bridge
		PipelineContract.step("seedSelfContainedHandlers");
		seedSelfContainedHandlers();
		PipelineContract.step("resolveFileScopeIncludeProvenance");
		resolveFileScopeIncludeProvenance();   // ITEM18 Part 2: needs entryPriv (populated above)
		PipelineContract.step("auditAccessControl");
		auditAccessControl();
		PipelineContract.step("emitControlReachabilityCandidates");
		emitControlReachabilityCandidates();   // after sinks + entry seeding are populated

		PipelineContract.step("dumpSummaries");
		dumpSummaries();             // export Layer-1B return/hook summaries AFTER all seeding populated
		                             // retArbitraryFids / topFunIds / sinks (WP_DUMP_SUMMARIES=1 only)
		PipelineContract.step("reset");
		PipelineContract.finish();
		reset(cg);
		
		return cg;
	}