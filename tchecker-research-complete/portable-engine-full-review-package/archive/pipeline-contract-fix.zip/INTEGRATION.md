# PipelineContract integration — 3 steps, all additive

## What this fixes
The 44-pass `newInstance()` pipeline communicates through shared statics; its 49
ordering constraints existed only as line order + comments. This makes them checked
at runtime, catching four failure classes:
- ORDER   — a pass ran before a pass it depends on (the entryPriv/MOVED incident)
- VACUITY — a pass reads a field its writers left empty (the "check never fired" bug)
- FREEZE  — a frozen field (call2mtd after dispatch augmentation) mutated late
- DRIFT   — a pass wrote a field the contract says it doesn't (stale contract alarm)

## Safety model (matches the checkpoint-caution decision)
Inert unless env var set. `WP_PIPELINE_CONTRACT=warn` prints violations to stderr,
never throws, exit code unchanged — safe on the seven-corpus gate immediately.
`=strict` throws at finish() — CI only. Unset = zero output, zero cost.
No pass is reordered; every original line of newInstance is preserved verbatim
(verified mechanically during patch generation).

## Steps
1. Drop `cg/PipelineContract.java` into the `cg` package. (Compiles standalone,
   java.util only — verified with javac 21.)
2. Replace `newInstance()` with `NEWINSTANCE_PATCHED.java`'s version — or apply the
   same three kinds of insertions by hand:
   - probe block right after `CG cg = new CG();` (adjust the two cross-class probe
     field paths — sources/sqlSanitizers live on PHPCSVEdgeInterpreter — to your
     actual imports)
   - `PipelineContract.step("<passName>");` immediately before each of the 43 pass
     calls (generated for you in the patched file)
   - `PipelineContract.freeze("call2mtd");` after augmentInstanceDispatchEdges();
     `PipelineContract.finish();` before reset(cg);
3. Run one checkpoint corpus with `WP_PIPELINE_CONTRACT=warn`. Expected: 0 violations
   on the current ordering. Any VACUITY warning on the CURRENT order is a latent bug
   of the entryPriv class — investigate before the refactor, it means a check that
   never fires today.

## Regenerating the contract after adding/moving a pass
The constraint table is generated from a transitive read/write scan of the source
(pipeline_contract.json holds the data; the scan script is in the repo notes). If a
DRIFT warning appears, a helper started writing a field the table doesn't know —
rerun the scan and paste the regenerated CONSTRAINTS/READS/WRITES_ALL blocks.

## During the migration split
Keep the contract on in warn mode while extracting the WordPress passes into the
plugin: any split that changes effective ordering shows up as ORDER/VACUITY lines
on the very first run, instead of as silently shifted finding counts three steps later.
