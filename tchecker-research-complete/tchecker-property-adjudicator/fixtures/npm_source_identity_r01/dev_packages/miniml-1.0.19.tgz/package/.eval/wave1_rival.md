# WAVE 1 — THE RIVAL

## Position (2 sentences — who you are and whether MiniML threatens you)

I am the CEO of Cube (cube-js/cube — the open-source universal semantic layer, ~20,300 GitHub stars, ~30,400 weekly npm downloads of `@cubejs-backend/server-core` alone, repositioned in 2026 as "the agentic analytics platform" with D3 and a hosted MCP server), and I picked us as the rival because MiniML's entire alternatives.md is written *against our weaknesses* — "requires a running server," "open-core," "Cube Cloud is commercial" — which means we are the incumbent it is trying to route around. MiniML does not threaten us today at 1 GitHub star, 0 forks, and 57 npm downloads/month, but the *architectural idea* it represents — a deterministic, zero-infrastructure metadata-to-SQL compiler you hand to an LLM as a tool — is exactly where the market is going, and someone else (not MiniML) is already executing it.

## Evidence (the memo: what we'd copy, what we'd ignore and why, our counter-pitch)

**TO: Cube leadership team**
**FROM: CEO**
**RE: dtempx/miniml — assessment and counter-positioning**

### Who this is

A ~1,000-LOC MIT TypeScript library (npm `miniml` v1.0.17) by one engineer (Dave Templin) that compiles YAML models (dimensions/measures/joins/date logic) into BigQuery/Snowflake SQL, explicitly pitched as "the safe vocabulary layer for LLM text-to-SQL." [MEASURED — read the repo at /home/user/projects/miniml: README.md, documentation/alternatives.md, TASKS.md, lib/]

Vital signs I pulled myself:
- **1 star, 0 forks, 0 open issues, 0 watchers-beyond-author** on GitHub. [MEASURED — api.github.com/repos/dtempx/miniml, 2026-07-03]
- **57 downloads last month, 19 last week** on npm. Statistical zero; bots alone usually beat that. [MEASURED — api.npmjs.org/downloads/point/last-month/miniml]
- **25 commits, 9-month dormancy** (Sep 2025–May 2026), revived Jun–Jul 2026 with docs/keywords, not features. [MEASURED — git log]
- Search discoverability is broken: "miniml" surfaces a synaptic-event deep-learning tool (delvendahl/miniML) and an ML teaching language before this project. It does not appear in any 2026 "open-source semantic layer" roundup I found. [SOURCED — https://github.com/delvendahl/miniML, https://medium.com/@grom_65116/best-open-source-semantic-layer-tools-in-2026-f99565169ccc]
- Its own TASKS.md openly lists serious unfixed bugs: `date_from == date_to` returns no rows, non-TIMESTAMP date fields generate failing SQL, order_by on expression fields breaks, date_granularity misapplied. [MEASURED — /home/user/projects/miniml/TASKS.md]
- README keywords say "mcp" / "model context protocol"; **no MCP server exists in the repo**. Aspiration, not product. [MEASURED]

### Why we (Cube) are the closest threat, not dbt or Snowflake

- dbt Semantic Layer's queryable API is dbt-Cloud-gated and adoption is soft (~18% in one 500-team analysis) — it competes on the dbt install base, not on "embed a semantic layer in your agent." [SOURCED — https://www.typedef.ai/resources/semantic-layer-metricflow-vs-snowflake-vs-databricks]
- Cortex Analyst is Snowflake-only and *agentic* (LLM in the query path); MiniML is deliberately the opposite (deterministic compiler, LLM outside). Different category. [SOURCED — https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-analyst]
- Malloy is a new DSL with a training-cost adoption wall, and the team just moved from Google to Meta — niche trajectory. [SOURCED — https://davidsj.substack.com/p/open-semantic-interchange, https://github.com/malloydata/malloy]
- We are the one MiniML's README names first when it says "lightweight, zero-infrastructure alternative to heavyweight semantic layers." Its sales pitch is literally "Cube minus the server." That makes it ours to crush. [MEASURED — alternatives.md feature table]

### What we'd copy in a sprint

1. **AST-validated freeform `where`/`having` from untrusted callers.** MiniML lets an LLM pass raw SQL filter expressions and validates them via node-sql-parser against an allowlist + the model's column vocabulary (subqueries, DDL/DML, comments, unknown columns all blocked; 68 tests, almost all on this path). Our structured filter operators are safer but clunkier for agents; a validated raw-expression escape hatch would measurably improve agent ergonomics. One sprint, high value. [MEASURED — README Security section, test/validation.test.ts]
2. **Compact LLM-facing model descriptions as a first-class output.** `npx miniml model.yaml` emits a tight markdown vocabulary (dimensions + measures + descriptions) sized for a system prompt, plus Jinja-templated `info`. Our /meta endpoint returns everything; a "prompt-sized model card" generator for our MCP server is a weekend of work and good marketing. [MEASURED — README Quick Start]
3. **The terse YAML shorthand** (`measure_name: description` → `SUM(measure_name)`, array form `[description, sql, join]`). Onboarding friction matters; our cube definitions are wordier. Worth a "quick-start schema" mode. [MEASURED — lib/load.ts behavior per CLAUDE.md + README]
4. **The honest fan-out warning doc.** Not code — posture. Their fanout.md openly says "we will silently over-count, here's why." We *solve* fan-out and should market against tools that don't with the same candor. [MEASURED — documentation/fanout.md referenced from README]

### What we'd never copy (and why)

1. **String-pasted joins with no join graph.** MiniML joins are literal SQL strings rendered in YAML-definition order, with zero fan-out protection — additive measures silently over-count on one-to-many joins. This is not minimalism, it's the absence of the hardest and most valuable part of a semantic layer. Our join graph + correctness handling is exactly the moat this proves the worth of. [MEASURED — README "Joins" section and fan-out warning]
2. **Zero-infrastructure as identity.** "No server" also means no caching, no pre-aggregations, no row-level security enforcement, no concurrency layer, no query queue, no APIs. Those aren't bloat; they're why enterprises pay us. Copying "nothing" is free and worth what it costs. [SPECULATION as strategy judgment; feature absence is MEASURED — alternatives.md admits all of this]
3. **Hand-rolled per-dialect string templating (2 dialects).** `dialect.ts` string-builds BigQuery/Snowflake variants and infers dialect *from the file path*. We support dozens of engines through real adapters. The marginal dialect in their architecture is a rewrite; in ours it's config. [MEASURED — README "SQL Dialect Detection", TASKS.md refactor item]
4. **`SELECT *` fallback when no fields specified** (their open TODO). An anti-feature in a governed layer; teaches agents to bypass the vocabulary. [MEASURED — TASKS.md]

### Counter-pitch to steal their would-be users

Target user: a TypeScript developer embedding "chat with your data" into an app, allergic to running infrastructure.

> "You looked at MiniML because you want a governed vocabulary for your LLM without adopting a platform. Fair. But Cube Core is Apache-2.0 and free too — `docker run cubejs/cube` is one command, and for that you get the same YAML modeling **plus** the things MiniML's own docs admit it will never give you: join fan-out protection (your revenue numbers won't silently double), every major warehouse (not two), row-level security your CISO will actually accept, sub-second caching so your agent doesn't hammer Snowflake per question, and REST/SQL/GraphQL/MCP endpoints your agent can call today — the MCP server exists and ships, it isn't an npm keyword. MiniML returns a SQL string and wishes you luck executing it, securing it, and paying the warehouse bill for every repeated question. And check the maintenance math: one author, one star, 25 commits, a public TASKS.md where 'same start and end date returns no rows' has sat unfixed through a nine-month dormancy. When you outgrow it — their own roadmap item 'join between models' tells you that you will — you rewrite on us anyway. Skip the rewrite."
> [Star/download/commit figures MEASURED; Cube MCP server + Apache-2.0 core SOURCED — https://cube.dev/docs/product/apis-integrations/mcp-server, https://github.com/cube-js/cube]

One more thing, team: the *niche itself* is real and is being won by someone else. **Boring Semantic Layer** (boringdata, Python/Ibis, MCP-native, multi-engine via Ibis) is the actual head-to-head for "tiny deterministic semantic layer for agents," and it has newsletter reach, a v2, and community momentum MiniML entirely lacks. If a lightweight compiler ever eats our low end, it will be BSL-shaped, not MiniML-shaped. Watch BSL; ignore MiniML. [SOURCED — https://github.com/boringdata/boring-semantic-layer, https://juhache.substack.com/p/boring-semantic-layer-mcp, https://tldr.tech/data/2025-07-07]

## Strongest point FOR the project

The architecture bet is correct and early-stated: keep the LLM *out* of the SQL path, hand it a compact governed vocabulary, and compile its structured selection deterministically — reproducible, auditable, injection-hardened. The entire 2025–26 industry converged on exactly this pattern (our own MCP positioning, Snowflake's semantic-model YAML grounding claiming ~2x accuracy over raw GPT-4o text-to-SQL, the MCP-semantic-layer wave), and MiniML is the *only* option that delivers it as a pure MIT library with literally zero infrastructure — a genuinely unoccupied cell in the TypeScript ecosystem, with unusually honest, complete documentation for a 25-commit project. [SOURCED — https://www.snowflake.com/en/blog/engineering/cortex-analyst-text-to-sql-accuracy-bi/, https://cube.dev/blog/unlocking-universal-data-access-for-ai-with-anthropics-model-context; MEASURED — repo docs]

## Strongest point AGAINST

Zero traction after 13 months (1 star, 0 forks, 57 npm downloads/month, no external contributor, no CI, 9-month dormancy) combined with a fatal product contradiction: it sells itself as the *safety* layer for conversational analytics, but it has no fan-out protection — so it protects you from SQL injection while letting the LLM-composed query silently return **wrong numbers**, and wrong numbers (not injection) are the failure mode that actually kills chat-with-your-data deployments. A safety layer that guarantees the query is well-formed but not that the answer is right is solving the easy half of the problem. [MEASURED — GitHub/npm APIs 2026-07-03, README fan-out warning, documentation/fanout.md]

## Viability score: 20/100

(Scored after analysis: ~10 points for a correct thesis, working two-dialect pipeline, real injection-validation engineering, and honest documentation; ~10 for probable continued dogfooded survival at Wayvia. Everything above that requires adoption evidence that measurably does not exist, in a niche where Cube owns the top, BSL is taking the bottom, and Cortex/Databricks own the warehouse-native flanks.)

## The one question that would change my mind

Is there even **one** paying-workload production adopter who is not the author's own employer — i.e., can anyone show npm downloads inflecting past ~1,000/week or a single external company running MiniML in an agent's query path? If yes (especially alongside a shipped MCP server and fan-out handling), this stops being a personal tool with a great README and becomes the seed of the "SQLite of semantic layers," and I would rescore to the 45–55 range and tell my team to ship the copyable items above *this* sprint instead of next quarter.
