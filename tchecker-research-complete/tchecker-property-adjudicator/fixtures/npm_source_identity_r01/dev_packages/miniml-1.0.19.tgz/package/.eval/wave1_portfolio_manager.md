# Wave 1 — Portfolio Manager (Opportunity-Cost Accountant)

## Position (2 sentences)
MiniML is a cheap-to-carry, employer-compounding side asset with effectively zero external adoption and an author whose measured distribution capacity (across three years and two OSS ecosystems) tops out at 4 GitHub stars — so its viability as a *community* open-source project is close to nil, while its viability as dogfooded Wayvia infrastructure that happens to be public is high. The correct portfolio move is to keep it, keep costs near zero, and abandon the implicit adoption campaign (keyword/README marketing with no distribution channel) unless the author is willing to buy distribution with the one thing he demonstrably doesn't have: sustained off-hours time.

## Evidence

### Portfolio scan
- [MEASURED] GitHub `dtempx` profile: 9 public repos, 4 followers. Portfolio is two ecosystems: **SyphonX** (web-extraction: syphonx, syphonx-core, syphonx-chrome, syphonx-lib, syphonx-examples) and **miniml**. Star counts via GitHub API: miniml 1★/0 forks/0 issues/0 watchers; syphonx-core 4★; syphonx-chrome 4★; syphonx 1★; syphonx-lib 0★. His *career-best* OSS outcome is 4 stars. [SOURCED: https://api.github.com/repos/dtempx/miniml, https://github.com/dtempx]
- [MEASURED] npm registry: syphonx-lib has co-maintainer `joel.spitler@pricespider.com` — SyphonX is PriceSpider/Wayvia employer tooling published on a personal account. syphonx-core was pushed 2026-06-30, the same fortnight as the miniml revival: his OSS hours are one shared pool, allocated to whatever the day job touches that month. [SOURCED: registry.npmjs.org search maintainer:dtempx]
- [SOURCED] Author identity: Dave Templin, **Head of Data & AI at Wayvia (formerly PriceSpider)**, prior Software Architect at PriceSpider 2012–2020 (https://www.linkedin.com/in/dtemp/, https://www4.lead411.com/Dave_Templin_24980087.html). This is a senior leadership role — his hours are executive hours, not IC hours.
- [MEASURED] miniml npm downloads, publish (2025-06) through 2026-07: **2,009 total**. Monthly curve tracks his own commit activity (peak 613 in Aug 2025 during active dev; 20–120/month during dormancy — mirror-bot/scanner noise floor). Since the June 2026 marketing revival: 77 downloads. External adoption ≈ 0. [SOURCED: api.npmjs.org/downloads/range]
- [MEASURED] SyphonX packages each pull ~1,800–1,900 downloads/month, dependents ≤1, PriceSpider co-maintainer — consistent with internal Wayvia CI consumption, not community adoption.

### Cost/month estimate
- [MEASURED] 25 commits in 13 months, distribution: Jun 2025 (4), Jul (6), Aug (7), Sep 2025–May 2026 (**0**), Jun 2026 (7), Jul (1). Average ≈ 2 commits/month, actual pattern is bursts.
- [SPECULATION, anchored to the above] Realized cost: ~4–8 hrs/month averaged, and most of it is plausibly on-the-clock Wayvia work (June 2026 commits "Fix order_by issue" and "add special logic for bigquery string literals" read as production-driven fixes). Issue triage cost at 0 open issues and 0 users: $0.
- [MEASURED] TASKS.md carries 10 open items, several correctness bugs (date_from==date_to returns no rows; non-TIMESTAMP date_field generates failing SQL; order_by on expression fields breaks) plus feature-scale items (per-dialect refactor, model-to-model joins, tags/access scheme). [SPECULATION] Closing the gap to a stranger-grade v1 + the README's aspirational MCP positioning (keywords exist, zero MCP code exists) = 2–4 engineering-months, i.e. 300–600 hours of off-hours time the git log proves he does not have.

### Unfair-advantage audit
- **Domain access: REAL and rare.** Head of Data & AI at a company running Snowflake-based conversational analytics = a production deployment to dogfood against. Most semantic-layer side projects die without exactly this. [SOURCED: LinkedIn title + Snowflake-centric repo usage]
- **Distribution: NONE.** 4 GitHub followers; a Twitter account (https://twitter.com/davetemplin) with no discoverable miniml promotion; no blog posts, no HN/Reddit launch found in search; June 2026 "revival" spent ~5 of 8 commits on README/keywords — marketing effort poured into a channel (npm/GitHub organic search) where the name collides with the MiniML teaching language. [MEASURED/SOURCED]
- **Credibility: proves shipping, disproves marketing.** Three years of SyphonX shows he can build and document quality libraries (miniml's 925-line README, 68 passing tests, AST-based injection validation are genuinely above-average craft) — and that this craft alone converts to ~4 stars. [MEASURED]
- **Proprietary data: none.** [MEASURED]

### Compound-or-fragment
- [MEASURED-adjacent] **Compounds.** miniml is the extracted core of his day job; every production bug fixed at Wayvia lands in the public repo for free. Archiving frees approximately zero hours, because the code would persist as internal tooling and the maintenance is work-driven either way. The only genuinely discretionary spend was the June 2026 doc/keyword push (est. 10–20 hrs [SPECULATION]) — which bought 1 star and 77 downloads.

### Dormancy analysis
- [MEASURED] 9 months dark (Sep 2025–May 2026) while syphonx-core still got a publish (Oct 2025): the dark period was not life interruption, it was *priority reallocation within the same OSS-hours pool*. The revival is 2 production bug fixes + 6 docs/keywords commits.
- [SPECULATION, high confidence] Next-12-months prediction: 2–4 burst windows totaling 15–30 commits, all triggered by Wayvia production needs; no MCP server unless Wayvia needs one; stars end 2027 in single digits absent a deliberate launch (HN post, blog, conference talk) that his 3-year track record says he won't do.

## Strongest point FOR the project
It is nearly free to hold and asymmetric: the author's employer already needs and funds its maintenance (production-driven fixes land in public for $0 marginal cost), and if "safe SQL vocabulary for LLM agents" becomes a standard pattern, a working, well-documented, MIT, zero-infrastructure incumbent with 13 months of production hardening is a lottery ticket he holds without paying premiums.

## Strongest point AGAINST
Every measurable proxy for his ability to convert craft into adoption already exists and reads zero: three years, six repos, two ecosystems, ~4 peak stars, 4 followers, no launch post ever — so the June 2026 keyword-marketing pivot is spending real hours on an adoption outcome his own portfolio history predicts will not occur, and those are the only hours in this project that are actually discretionary.

## Viability score: 32/100

## The one question that would change my mind
Will Wayvia formally adopt miniml as the semantic layer inside a customer-facing conversational-analytics product (not just an internal experiment) — because that converts his employer from a passive subsidizer into an active sponsor, funds the MCP server and multi-dialect roadmap on company time, and is the only mechanism visible in the evidence that gets this project distribution and maintenance hours it will never get from nights and weekends.
