# WAVE 1 — THE BEAR

## Position (2 sentences)
MiniML is a competently written internal tool wearing an open-source costume: after 13 months on public npm and GitHub it has 1 star, 0 forks, 0 issues, and a download curve that tracks the author's own commit activity almost perfectly — measurable external demand is zero. It competes in a category where every incumbent (Cube, dbt, Snowflake itself) already ships the exact "semantic layer + MCP for AI agents" product for free, while MiniML's own TASKS.md admits its core promise — correct SQL — is broken in common cases; kill it as a public project today and keep it as Wayvia tooling.

## Evidence

**Demand is zero, and I can prove the downloads are the author.**
- [SOURCED] GitHub API (https://api.github.com/repos/dtempx/miniml): **1 star, 0 forks, 0 open issues, 0 subscribers** after 13 months (created 2025-06-09). Zero issues is not cleanliness — with 10 known bugs listed in TASKS.md, zero filed issues means zero users ever hit them.
- [SOURCED] npm downloads API (https://api.npmjs.org/downloads/range/2025-06-01:2026-07-03/miniml): **1,463 total downloads in 13 months**. Monthly shape: Jun/Jul/Aug 2025 = 283/426/814, then Sep 2025–May 2026 = 16–115/month.
- [MEASURED] git log: 17 commits Jun–Aug 2025, dormant Sep 2025–May 2026, 8 commits Jun–Jul 2026. The download peak (Aug 2025, incl. single days of 154 and 113 — consistent with one dev's install/CI loops) coincides exactly with the author's commit burst; the dormant months' 16–115/month is registry-mirror/bot baseline. The correlation of downloads to the author's own activity is [SPECULATION] as to cause, but the numbers themselves are sourced, and there is no alternative signal (no stars, no issues, no forks) suggesting a human user base.
- [MEASURED] package.json keywords include "mcp" and "model context protocol"; no MCP server exists anywhere in the repo. The 2026 revival is 5 of 8 commits touching only README/keywords/docs (git log: "readme update" x3, "update keywords", "Add more info on miniml alternatives"). That is SEO for a product that hasn't changed, not development.

**Differentiation: the moat is already owned by giants who give it away.**
- [SOURCED] Snowflake ships a first-party open-source MCP server with Cortex Analyst and semantic view consumption (https://github.com/Snowflake-Labs/mcp) — MiniML's primary dialect is covered by its own vendor, free, with the MCP integration MiniML only has as a keyword.
- [SOURCED] dbt runs a remote MCP server over its Semantic Layer with a published chat-with-your-data reference app (https://github.com/dbt-labs/streamlit_mcp_cortex); Cube exposes governed models to agents over MCP/SQL/REST and has marquee AI-agent case studies (https://cube.dev/articles/semantic-layer-for-ai-agents-2026). The "safety layer for text-to-SQL" thesis is correct — and that's the problem: it's so correct that every incumbent pivoted to it before MiniML's author returned from a 9-month absence.
- [MEASURED] MiniML's claimed edge ("no service/account requirements, no cost" — README.md line 14) does not distinguish it from Cube Core (open source) or from Snowflake's free semantic views. Two dialects, no dbt integration, no governance/RBAC (tags scheme is an unchecked TASKS.md item #5).
- [MEASURED] Name collision: "MiniML" is the classic ML teaching language (typed lambda calculus, in every PL textbook). Organic search discovery is crippled at birth; my own search for the package surfaced it only via exact npm match.

**Execution capacity: one author, and the product's core promise is broken.**
- [MEASURED] TASKS.md openly lists 10 unresolved defects, several fatal to the value proposition of "correct, optimized SQL": `date_from == date_to` returns no rows ("a common scenario", the author's words, line 5); non-TIMESTAMP date fields generate SQL that fails outright (lines 13–18); `order_by` on expression-backed date fields causes SQL errors (line 11); date_granularity misapplied (line 1). A safety layer that emits broken SQL for same-day queries is not a safety layer.
- [MEASURED] Test suite is a single file (test/validation.test.ts) — 68 tests weighted toward injection validation; query-generation correctness (where the known bugs live) is lightly tested. No CI, no GitHub Actions, no CONTRIBUTING.md. Compiled .js/.d.ts artifacts are committed alongside source in lib/ — a solo-dev workflow, not a project ready for contributors.
- [MEASURED] 25 commits total, single author, one 9-month dormancy already on record. Base rate for solo repos resuming sustained feature work after a dormancy of that length, when the revival is docs-only, is dismal. [SPECULATION on the base rate; the dormancy and docs-only revival are measured.]
- [MEASURED] README bugs signal drift: line 913 says `npx mocha test/**/*.test.js` while package.json defines `npm test`; the quickstart's generated SQL (README line 120) applies `DATE(sale_date) >= CURRENT_TIMESTAMP - INTERVAL 7 DAY` — comparing a DATE to a TIMESTAMP, the exact class of bug TASKS.md admits. The shop window itself displays the defect.

## Strongest point FOR the project
The engineering honesty and code quality are genuinely above average for a solo repo: a working two-dialect compiler pipeline in ~1,000 LOC, AST-based SQL-injection validation via node-sql-parser (a real, hard feature most hobby projects fake with regexes — and TASKS.md shows he refactored from regex to AST deliberately), 68 passing tests, a 925-line README with an honest fan-out warning and an alternatives comparison that steelmans the competition. [MEASURED] And the market thesis is validated — by the incumbents' own pivots. If demand existed, this codebase could receive it.

## Strongest point AGAINST
Thirteen months of public existence produced **one star, zero forks, zero issues, and ~1,463 npm downloads whose peaks coincide with the author's own commit bursts** [SOURCED/MEASURED] — while the exact product category exploded around it and the incumbents (Snowflake first-party, dbt, Cube) shipped the MCP-integrated version of MiniML's roadmap for free. This is not an early project awaiting discovery; it is a completed market test that returned a null result.

## Viability score: 12/100
(The 12 is the code quality and the author's demonstrated ability to build; demand and differentiation contribute approximately nothing. As a public open-source project with adoption ambitions, this is a kill. As private Wayvia infrastructure it can quietly live on — but that is not the question.)

## The one question that would change my mind
Show me **one external production user I cannot trace back to the author** — a filed issue, a dependent package, a fork with commits, or a download pattern uncorrelated with dtempx's own activity. Zero-to-one on that single axis would force me to re-price everything; absent it, the market has already ruled.
