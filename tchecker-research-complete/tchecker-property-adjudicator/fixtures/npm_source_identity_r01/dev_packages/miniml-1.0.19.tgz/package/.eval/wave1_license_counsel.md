# Wave 1 — License & IP Counsel Brief

> **Scope note:** This is adversarial analysis to inform questions for a real attorney. It is not legal advice, and no attorney–client relationship exists.

## Position (2 sentences)

The license paperwork inside the repo is clean and every one of the 101 installed packages is permissively licensed, so there is zero copyleft contamination — but the git history shows 24 of 25 commits authored under the author's **employer email** (`dave.templin@pricespider.com`, PriceSpider = Wayvia) while the LICENSE claims personal copyright, meaning the person granting the MIT license may not actually own the thing he is licensing. Add a name that collides with a 40-year-old PL teaching language, an NCBI bioinformatics format, and a trademarked UK consumer brand, and this project's IP position is a fixable-but-currently-serious liability that no cautious corporate adopter's OSS review would pass without answers.

## Evidence

### 1. License consistency — CLEAN
- [MEASURED] `/home/user/projects/miniml/LICENSE`: standard MIT text, "Copyright (c) 2025 Dave Templin (dtempx@gmail.com)".
- [MEASURED] `/home/user/projects/miniml/package.json`: `"license": "MIT"`, `"author": "Dave Templin <dtempx@gmail.com>"`. File and field agree. No SPDX issues.

### 2. Dependency licenses — CLEAN, one Apache-2.0 nuance
- [MEASURED] Runtime deps (from installed `node_modules/*/package.json`): `cli-options@1.0.0` MIT; `he@1.2.0` MIT; `node-sql-parser@5.3.9` **Apache-2.0**; `nunjucks@3.2.4` BSD-2-Clause; `word-wrap@1.2.5` MIT (post-CVE-patched version); `yaml@2.8.0` ISC.
- [MEASURED] Full scan of all 101 installed packages (incl. dev deps and transitives such as `big-integer`, `@types/pegjs`): **zero** GPL/LGPL/MPL/unknown licenses. The dossier's worry about a GPL SQL-parser variant does not apply — this parser is Apache-2.0, verified against its bundled LICENSE file; no NOTICE file present.
- [SPECULATION → lawyer question] Apache-2.0 is MIT-compatible with no copyleft; the only real obligation lands on downstream embedders who *bundle* (e.g., webpack/esbuild single-file builds must carry the Apache-2.0 text and attribution for node-sql-parser). Apache's explicit patent grant on the SQL parser is actually a mild plus for enterprise embedders.
- [MEASURED] Provenance quirk on the "obscure" dep: `cli-options` is the author's **own** package (same author string, same 2025 personal copyright), and its `package.json` repository field points to `github.com/dtempx/parseargs` — a name-mismatched repo. Not a license problem, but a supply-chain-review yellow flag (single-maintainer dep whose declared repo doesn't match its package name).

### 3. THE EMPLOYER PROBLEM — the worst fact pattern available, and it's in the git log
- [MEASURED] `git shortlog -sne --all`: 16 commits as `Dave Templin <dave.templin@pricespider.com>`, 8 as `PS-davetemplin <dave.templin@pricespider.com>`, exactly **1** as `dtempx <dtempx@gmail.com>`. First commit day (2025-06-09) already mixes both identities; everything since 2025-06-12, including the entire 2026 revival, is employer-email, employer-provisioned-looking account (`PS-` prefix = PriceSpider).
- [SOURCED] PriceSpider rebranded as Wayvia, an "AI-driven commerce intelligence" company whose flagship recent launch is **Wayvia MCP** — natural-language / AI-agent access to commerce data ([wayvia.com](https://wayvia.com/), [P2PI: PriceSpider rebrands as Wayvia](https://p2pi.com/pricespider-rebrands-wayvia-unveils-ai-driven-commerce-intelligence-engine), [Yahoo Finance](https://finance.yahoo.com/news/wayvia-ushers-era-ai-driven-160100773.html)). MiniML is a semantic layer for LLM text-to-SQL with Snowflake support and "mcp"/"model context protocol" keywords — i.e., it **directly relates to the employer's actual line of business**, and per the dossier the author dogfoods it at Wayvia.
- [SPECULATION, jurisdiction-dependent] Wayvia has a Los Angeles presence ([Built In LA](https://www.builtinla.com/company/wayvia-formerly-pricespider)). If the author is California-based, Labor Code §2870 protects employee side projects **except** those that "relate to the employer's business or actual or demonstrably anticipated research" — the exception, not the protection, is what applies here. In assignment-friendlier states the position is worse. Either way, a typical Proprietary Information and Invention Assignment agreement would give Wayvia a colorable ownership claim over most of this codebase, and the commit metadata is the evidence trail.
- Consequence if Wayvia owns it: the personal-name copyright notice is wrong, the MIT grant was made by a non-owner, and every downstream user's license is clouded. This is precisely the scenario corporate OSS-ingestion reviews are built to catch.
- **Questions to put to a lawyer NOW:** (1) What does my invention-assignment / PIIA actually say, and which state's law governs? (2) Does MiniML fall inside "relates to employer's business" given Wayvia MCP? (3) Can I obtain a written IP waiver / open-source release from Wayvia (many companies grant these), or a copyright assignment back to me? (4) Does committing from a company email/account/laptop constitute work-made-for-hire evidence? (5) If Wayvia benefits from using it, is a Wayvia-signed CLA or joint-copyright notice the cleaner fix?
- **Hygiene that matters going forward** [SPECULATION as to legal weight, but standard practice]: commit only from personal email/equipment/hours; get the waiver in writing *before* the project has value; correct the copyright line only after ownership is actually resolved (papering over it now makes the record look worse, not better).

### 4. THE NAME — low trademark risk, high discoverability damage
- [SOURCED] "mini-ML" is the canonical toy-ML teaching language from Clément/Despeyroux/Kahn's 1986 ACM LISP paper ([dl.acm.org](https://dl.acm.org/doi/10.1145/319838.319847)), still used in PL courses ([Cambridge MiniML page](https://www.cl.cam.ac.uk/~mom22/miniml/)) with multiple existing GitHub repos named `miniml` (e.g., [aprell/miniml](https://github.com/aprell/miniml)).
- [SOURCED] **MINiML** is NCBI GEO's "MIAME Notation in Markup Language," an established bioinformatics XML format ([ncbi.nlm.nih.gov](https://www.ncbi.nlm.nih.gov/geo/info/MINiML.html)) — searching the exact string surfaces this prominently.
- [SOURCED] **Miniml** is a UK eco-cleaning consumer brand founded 2020 ([minimlrefills.co.uk](https://minimlrefills.co.uk/)) that dominates plain "miniml" web search.
- [SPECULATION → lawyer question] Trademark *infringement* risk is low: the cleaning brand is a different Nice class; the academic dialect and the NCBI format are almost certainly unregistered as software marks. But a clearance search for "MiniML" in software/SaaS classes (US Class 9/42) has not been done and should be, *before* any commercial/dual-license move.
- [MEASURED/SOURCED] Searchability is the real cost: "miniml" search results are split between soap refills, a bioinformatics format, and PL-course repos; "ML" itself now reads as "machine learning" and pulls TinyML noise. A stranger who hears the name cannot reliably find the package — the dossier's own npm search even surfaced a stale version snippet. For a project whose 2026 activity is explicitly adoption marketing, the name is working against every dollar of that effort.

### 5. The relicensing trap — the decision window is open but won't stay open
- [MEASURED] Sole contributor today (one human, three git identities), no CONTRIBUTING.md, no CLA, no DCO, no CI to enforce either.
- Because he is (nominally) sole author, he can still relicense, dual-license, or move to BSL **unilaterally — but only until the first outside PR is merged**. Every merged external contribution under bare MIT is a permanent co-copyright he can never re-license without hunting down that contributor. With the repo now being marketed for adoption, this door can close any week.
- What must be decided NOW: (a) resolve Wayvia ownership first — a CLA assigning rights to someone who doesn't own the base code is worthless; (b) then pick CLA (keeps dual-license/BSL option open) vs DCO-only (community-friendly, forecloses proprietary relicensing); (c) add CONTRIBUTING.md and a PR gate before the first stranger's patch, not after.

## Strongest point FOR the project

The license surface a consumer sees is genuinely spotless: valid MIT LICENSE matching the package.json field, and a fully permissive dependency tree — all 101 installed packages are MIT/ISC/BSD/Apache-2.0 with zero copyleft, so embedding MiniML in a closed-source product carries no contamination risk, and the Apache-2.0 SQL parser even brings an explicit patent grant. [MEASURED]

## Strongest point AGAINST

The repository's own git metadata undermines the copyright notice it ships: 24 of 25 commits — including essentially all substantive development — were authored from `dave.templin@pricespider.com` on an employer-branded GitHub account, for a library squarely inside Wayvia's AI-commerce-intelligence business and apparently used there in production, while the LICENSE asserts personal ownership. Until Wayvia signs a written waiver or assignment, every MIT grant this project makes is potentially a license from someone who doesn't own the code, and any serious corporate adopter or acquirer who runs provenance diligence will see it in thirty seconds. [MEASURED commit data; ownership outcome is jurisdiction/contract-dependent — SPECULATION requiring counsel]

## Viability score: 40/100

Scored as license/IP posture, not code quality: the paperwork and dependency hygiene earn high marks, but an unresolved, well-evidenced employer ownership cloud over ~96% of commits is the kind of defect that silently caps adoption (corporate users) and forecloses monetization (no one buys or dual-licenses clouded title), and the name actively taxes discoverability. Every one of these is fixable — a Wayvia waiver, a CLA/DCO decision, possibly a rename — which is why this is 40 and not 15; unfixed, it is the project's ceiling.

## The one question that would change my mind

Does Dave Templin hold — or can he obtain — a written, signed acknowledgment from Wayvia/PriceSpider that MiniML is his personal property (or an explicit open-source release of it under MIT)? A yes converts the single worst finding into a footnote and would move my score to roughly 70; a no, combined with a standard invention-assignment agreement, means the project's copyright notice is wrong and everything downstream of it is built on sand.
