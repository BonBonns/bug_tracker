# MiniML — Open Source Project Viability Tribunal
### Final Verdict & Battle Plan

---

## Executive Verdict

**PIVOT — confidence: medium.** The problem MiniML targets is real and its architectural thesis has been vindicated as 2026 industry consensus, but the project as *currently positioned and shipped* misses that demand on every axis that matters: it competes on the two dialects (BigQuery, Snowflake) whose own vendors now ship this natively and auto-generate the models, its flagship "MCP" capability is an npm keyword with no code behind it, and its headline "AST-based safe SQL" control is **dead code that never executes** — a defect I verified directly, not one the panel merely asserted. The correct move is neither to double down on a foreclosed product nor to archive a near-free, dogfooded asset, but to run one cheap, time-boxed, kill-criteria-gated pivot to the single defensible opening anyone found — an MCP-native, warehouse-agnostic, TypeScript semantic layer — and let 90 days of pre-committed evidence decide.

The reconciled viability score is **~30/100 as it stands today**, with a credible path to the 50s *only if* the pivot's crux test lights up. If it doesn't, this converts cleanly to "archive the ambition, keep the code."

---

## What This Is

MiniML is a ~1,040-LOC MIT-licensed TypeScript library (npm `miniml` v1.0.17, author Dave Templin) that compiles terse YAML semantic models — dimensions, measures, joins, date logic — into BigQuery/Snowflake SQL. Its pitch: instead of letting an LLM write arbitrary SQL, you hand it a governed vocabulary and MiniML deterministically generates correct, injection-checked SQL. It is the safety/vocabulary layer for "chat with your data."

The core pipeline works. `npx miniml sales.yaml --dimensions=date --measures=total_amount` produces clean, correct Snowflake SQL in the first five minutes of use [MEASURED]. The YAML shorthand and the LLM-facing "model card" generator are genuinely good, separable engineering. But 13 months after first commit: **1 GitHub star, 0 forks, 0 external issues, ~288–2,000 lifetime npm downloads that spike only on the author's own publish days** [MEASURED — GitHub/npm APIs], a 9-month dormancy (Sep 2025–May 2026), and a June 2026 "revival" that was README rewrites and keyword-stuffing, not features or fixes.

---

## How the Panel Split (the disagreement map)

Final scores after Wave 2 cross-examination:

| Agent | W1 | W2 | Moved by |
|---|---|---|---|
| The Bull | 58 | **42** | −16: dead-code validation falsified his "safety is real code" point |
| The Bear | 12 | **18** | +6: Portfolio Manager's zero-cost / option-value evidence |
| License Counsel | 40 | **34** | −6: false security representations + Wayvia IP cloud |
| Principal Engineer | 34 | **34** | held: prototype-grade regardless of market |
| AI Futurist | 31 | **31** | held: obsolescence low, amplification unrealized |
| Portfolio Manager | 32 | **30** | −2: inert safety control cracks the "deeply dogfooded" claim |
| Community Architect | 30 | **30** | held: distribution works *if* author executes |
| Target User (Maya) | 30 | **30** | held: great first 5 min, unshippable for its marketed use |
| Security Auditor | 28 | **26** | −2: BigQuery function surface reachable through dead allowlist |
| Contrarian (W2) | — | **24** | new: cluster is anchored by "cheap-to-fix ⇒ will-be-fixed," which the 13-month-dead-code datum falsifies |
| Rival (Cube CEO) | 20 | **20** | held: doesn't register as a threat |
| Market Cartographer | 14 | **14** | held: hyperscalers already shipped it |
| Monetization | 14 | **14** | held: only career-capital pays at this traction |

**Where the panel CONVERGED (strong signal):**
- **The thesis is right.** Every agent, including the Bear and Rival, conceded that "constrain the LLM to a governed vocabulary, compile deterministically" is the correct and now-consensus architecture. [dbt's 2026 benchmark: 98–100% accuracy vs 84–90% for raw text-to-SQL — SOURCED]
- **Traction is a measured zero.** No dispute. 1 star, near-zero organic downloads, 13 months.
- **The operational instruction.** Optimist, pessimist, accountant, and contrarian all independently landed on: *keep the near-free dogfooded code alive; stop or gate the public-adoption spend.*

**Where the panel SPLIT (the real uncertainty):**

| Claim | For | Against | Whose evidence is better |
|---|---|---|---|
| "Cheap defects ⇒ will be fixed and launched" | Bull, Community | Bear, Contrarian, PE | **Against.** A one-line safety fix sat unmade for 13 months through a dormancy; the base rate is no-action. |
| "The open TS/MCP-native seat is a real wedge" | Bull, Cartographer (partial), Futurist | Rival, Bear | **Split.** The cell is genuinely empty (Cube needs a server; BSL/Zenlytic are Python), but nobody produced evidence it *converts* — only that it's unoccupied. |
| "Compounds the day job ⇒ don't archive" | Portfolio Mgr | (nobody disputes the code; Bear disputes the campaign) | **For, on the code.** Maintenance is employer-subsidized; archiving frees ≈0 hours. This is why the verdict isn't ARCHIVE. |
| "It's a product" vs "it's a notation" | whole panel (product) | Contrarian (notation) | **Mostly product.** The notation-upside is real but also needs distribution MiniML lacks. |

---

## The Crux

**Will one non-author organization put MiniML into production within 90 days of a real MCP server shipping?**

This is the single question that flips the verdict, and it is *cheaply testable* — which is why the ruling is PIVOT-with-a-test rather than decide-blind. The test costs roughly one 40-hour sprint plus one honest launch:

1. Ship the MCP server that the package keywords already promise (the code maps 1:1 onto an MCP toolset — `loadModel`/`renderQuery`/model-card generation).
2. Fix the dead-code AST validator and add a regression test that *asserts it runs* — so the differentiation is real.
3. Fix the README so the canonical Quick Start command runs verbatim, and fix the two date bugs.
4. Launch once, properly, into the channels that exist (awesome-mcp-servers ~90k stars; Show HN; dbt Slack).

**Pre-committed interpretation:** external adoption signal in 90 days → escalate to DOUBLE DOWN / continue the pivot. No signal → archive the ambition permanently, keep the library as private Wayvia tooling. This pre-commitment is the antidote to sunk-cost drift.

---

## Scorecard

Panel range → reconciled Judge score (0–100), one-line justification.

| Dimension | Range | Judge | Justification |
|---|---|---|---|
| Problem Severity | 60–85 | **78** | Real, articulated, benchmark-backed demand for governed LLM→SQL. |
| Market Timing | 30–70 | **45** | Right idea, arrived after the land rush; category consolidating upward into platforms. |
| Differentiation | 15–45 | **30** | TS/MCP-native zero-infra is a real empty cell — undercut by unbuilt MCP + inert safety control. |
| Technical Quality | 26–42 | **35** | Clean small codebase, good `load.ts`; but dead-code safety, string-concat SQL, 2 live bugs, one test file, no CI. |
| Distance to Usable | 30–50 | **45** | Happy path works today; broken canonical docs and missing MCP for its marketed use. |
| Security / Trust Posture | 26–34 | **28** | Flagship allowlist never executes; SSTI surface; no CI/provenance. Disqualifying-until-fixed for a security product. |
| License / IP Cleanliness | 34–42 | **40** | MIT + deps mechanically clean; real risks: name collision, Wayvia employer-IP cloud (24/25 commits from a pricespider.com address), now-false security claims. |
| Community Potential | 20–30 | **22** | 1 star, no CONTRIBUTING/CI, unsearchable name; channels exist but have never been activated. |
| Monetization Realism | 14–15 | **15** | Direct revenue ≈2/100; career capital is the only real return and it accrues to the author, not the project. |
| AI Amplification vs Obsolescence | — | **55** | Obsolescence risk *low* (warehouses building semantic models proves the layer gets more valuable); amplification *high-potential but unrealized* (MCP is a keyword). Net structural tailwind. |
| Author's Unfair Advantage | 30–40 | **40** | Genuine: production dogfooding at Wayvia = domain access. Capped by a ~4-star historical distribution ceiling and employer conflict. |
| Opportunity Cost (higher = cheaper to keep) | — | **65** | Maintenance compounds the day job at ≈0 incremental hours; the *only* real cost is the adoption campaign, which the verdict gates. |

**Reconciled overall viability: ~30/100 today.** The dimensions do not average to a single "keep/kill" number — the honest reading is a low-viability *product* riding a high-severity *problem* with a genuine but unrealized structural tailwind, gated on one cheap test.

---

## Verdict Rationale

**Why not DOUBLE DOWN.** Traction is a measured zero after 13 months, the primary market (BigQuery/Snowflake conversational analytics) is foreclosed by first-party vendor features that even auto-generate the models, and two flagship capabilities (MCP server, AST safety) are absent-in-execution. Doubling down on this positioning is pouring effort into a room that emptied.

**Why not ARCHIVE WITH HONOR.** The Portfolio Manager's evidence is decisive here and survived cross-examination: MiniML is the extracted core of the author's day job, its maintenance is employer-subsidized, and archiving frees ≈0 hours while destroying a live relicensing option and a real career-capital artifact. You don't archive a working, near-free, dogfooded asset. The thing to archive is the *ambition*, not the code — and only if the test fails.

**Why not MAINTAIN (mere lights-on).** The author convened this tribunal asking whether to keep going. "Keep it alive, invest nothing" is a soft kill dressed as a decision, and it ignores that the demand is genuinely real and a *precise* repositioning exists. The evidence supports a bounded bet, not resignation.

**Why PIVOT.** The demand is real (severity 78), the current implementation and positioning miss it precisely and diagnosably, and there is exactly one cheap, falsifiable test that resolves the uncertainty. PIVOT is not a claim of high viability — it is "the demand is real but this misses it; here is the specific correction and the 90-day evidence gate." The kill criteria below make it impossible for this to become years of sunk cost.

---

## Battle Plan

### 1. Positioning statement (sharp enough to be wrong)
> **For TypeScript engineers building AI agents that query data, MiniML is the only zero-infrastructure, warehouse-agnostic semantic layer that installs as an npm package and speaks MCP natively — no server, no platform, no vendor lock-in.**

This deliberately abandons the "better than Cube/dbt on Snowflake" framing (a fight against native vendor features) and stakes the one empty cell: *embeddable + TS + MCP-native*. It is falsifiable — if TS agent-builders don't want a library-shaped semantic layer, this positioning fails fast, which is the point.

### 2. The 90-Day Sprint (milestones in order)
- **Weeks 1–2 — Earn the right to be trusted.** Fix the dead-code AST validator (`validation.ts:280` — handle the object return from `astify`) and add a red-team regression test that *asserts the allowlist blocks a non-allowlisted function*. Fix the two date bugs (`query.ts:119` duplicated null check; single-day `BETWEEN`). Fix the README so every Quick Start command runs verbatim (hyphen vs underscore flags). Add a minimal CI (GitHub Actions: build + test). **Ruthless scope cut: do NOT add a third dialect, do NOT add `SELECT *` fallback, do NOT refactor `dialect.ts`.** None of that moves the crux.
- **Weeks 3–5 — Ship the hero.** Build and publish the MCP server (`@miniml/mcp` or a `miniml mcp` subcommand) exposing model discovery + query generation as MCP tools. This is the entire wedge; the code already maps onto it.
- **Weeks 6–8 — The 30-second demo.** A single GIF/asciicast at the top of the README: *Claude Desktop (or Cursor) connected to MiniML's MCP server, a plain-English question, correct governed SQL + result.* This is the artifact that earns a star in 30 seconds; today the repo has none.
- **Weeks 9–12 — Launch once, properly** (see distribution).

**The single hero demo:** an agent answering "revenue by plan tier last month" through MiniML's MCP server, showing the governed SQL it generated. That's the whole story in one loop.

### 3. Distribution machine (first 100 users, named channels)
Sequenced launch calendar (from the Community Architect's brief):
- **Day 0:** PR into `punkpeye/awesome-mcp-servers` (~90k stars) — gated entirely on the MCP server existing.
- **Day 1:** Show HN — draft title: *"Show HN: MiniML – an MCP-native semantic layer so your AI agent writes correct SQL, not arbitrary SQL."* First line leads with the demo GIF and the dbt-benchmark accuracy stat.
- **Week 1:** Post in dbt Community Slack (#tools-and-integrations, ~66k members) and the MCP Discord; write one technical blog post ("Why we put the LLM *outside* the SQL path") and submit to Data Engineering Weekly / TLDR Data.
- **Growth loop:** a **template gallery** — ship 5–10 ready-to-fork MiniML models for common warehouses (Stripe, Shopify, GA4 schemas). Each model a user publishes is discoverable and forkable, and each fork is a visible endorsement that recruits the next user. This is the repeatable mechanism, not "post and hope."

### 4. AI-leverage plan
- **Author uses agents to compress the roadmap:** backfill the thin query-generation test coverage (generate hostile WHERE/HAVING corpora), auto-generate the template-gallery models from warehouse schemas, and draft docs.
- **Project becomes agent-legible:** the MCP server IS the amplification play; add an `llms.txt` and ensure the model-card generator output is clean prompt material. Projects legible to agents get discovered by agents.

### 5. Monetization decision
**Pursue exactly one: career capital, via a free-and-excellent MIT library + author-fronted content.** Do NOT build a hosted version (negates the zero-infra differentiator, knife fight with $48M-funded Cube and the warehouses). **License/CLA decision that must land NOW, before any outside contribution arrives:** the author is currently sole copyright holder (0 forks), so the relicensing option is open — adopt a **DCO** (not a CLA-transfer) to keep provenance clean while preserving future dual-license optionality, and **resolve the Wayvia employer-IP question in writing** (24/25 commits from a pricespider.com address is a real cloud over every MIT grant). First paying-customer hypothesis is deferred until a single external production user exists.

### 6. Pre-registered kill criteria (committed NOW)
Measured at day 90 after the proper launch:
- **≥ 75 GitHub stars** from non-author accounts, **AND**
- **≥ 500 weekly npm downloads** sustained (not a launch-day spike), **AND**
- **≥ 3 inbound issues/PRs from strangers**, **AND**
- **at least 1 identifiable external org** trialing the MCP server.

Hit ≥3 of 4 → continue the pivot / escalate toward DOUBLE DOWN. Hit ≤1 of 4 → **archive the ambition**: keep MiniML as private Wayvia tooling, stop all public-adoption spend, redirect the freed hours. No renegotiating the thresholds after the fact.

### 7. The One Thing
**Ship the MCP server this month.** It is the wedge, the hero demo, the awesome-list ticket, and the crux test — all four at once. Nothing else on this list matters until it exists.

---

## Appendix — index of `.eval/` files

- `dossier.md` — shared fact base (Wave 0)
- **Wave 1 briefs:** `wave1_bear.md`, `wave1_bull.md`, `wave1_target_user.md`, `wave1_rival.md`, `wave1_principal_engineer.md`, `wave1_market_cartographer.md`, `wave1_security_auditor.md`, `wave1_license_counsel.md`, `wave1_community_architect.md`, `wave1_monetization.md`, `wave1_ai_futurist.md`, `wave1_portfolio_manager.md`
- **Wave 2:** `wave2_bull_rebuttal.md`, `wave2_bear_rebuttal.md`, `wave2_contrarian.md`, `wave2_panel_updates.md` (consolidated updates for the other ten)
- **This file:** `VERDICT.md`

### Provenance note
Nine Wave 1 briefs (Bear, Bull, Rival, Market Cartographer, Monetization, License, Community, AI Futurist, Portfolio Manager) were produced by independent parallel subagents. A session-limit API error then terminated the remaining agents mid-run; per the protocol's explicit sequential-fallback clause, the Orchestrator produced the Principal Engineer, Security Auditor, and Target User briefs and all of Wave 2 directly — but only after **independently verifying by executed probe** every load-bearing technical claim (dead-code AST validation, `SESSION_USER()` bypass, live nunjucks SSTI, the `date_to:null` and single-day date bugs, the README CLI-flag mismatch). Those findings are [MEASURED], not inherited. The market/traction figures throughout are sourced from the GitHub and npm APIs by the agents who ran them.
