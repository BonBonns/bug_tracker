# WAVE 1 — MARKET CARTOGRAPHER

## Position (2 sentences)
The market thesis behind MiniML is correct and demonstrably growing — "semantic layer as guardrail for LLM analytics" is the consensus 2026 architecture, validated by dbt's own benchmarks and by every hyperscaler shipping it natively — but that is precisely the problem: the niche has been simultaneously colonized from above (Snowflake Semantic Views, Databricks Unity Catalog Metrics, Looker/Gemini — all GA in 2026) and from beside (Boring Semantic Layer, Cube, dbt MCP server), while MiniML sits at 1 GitHub star, 0 forks, and ~288 npm downloads in six months. MiniML is a correct idea executed by one person, arriving after the land rush, in the wrong ecosystem corner (TypeScript, no MCP server, two dialects), with effectively zero footprint.

## Evidence

### Competitor map

| Competitor | Type | Weight class | LLM/MCP story | Link | Tag |
|---|---|---|---|---|---|
| Cube (Core + Cloud) | OSS + commercial | Heavy (server, caching, 4 APIs) | Dedicated "semantic layer for AI agents" positioning, MCP endpoint | https://cube.dev/articles/semantic-layer-for-ai-agents-2026 | [SOURCED] |
| dbt Semantic Layer / MetricFlow | OSS (Apache 2.0 since Oct 2025) + commercial | Heavy (dbt ecosystem) | Official dbt MCP server exposing governed metrics to agents | https://docs.getdbt.com/blog/introducing-dbt-mcp-server | [SOURCED] |
| Snowflake Semantic Views + Cortex Analyst | Native platform feature | Checkbox | Native NL→SQL grounded in semantic views; SQL querying GA Mar 2, 2026; "Semantic View Autopilot" auto-generates models, GA | https://docs.snowflake.com/en/user-guide/views-semantic/overview | [SOURCED] |
| Databricks Unity Catalog Metric Views + Genie | Native platform feature | Checkbox | UC Business Semantics GA and open-sourced early 2026; Genie Ontology context layer in preview Jun 2026 | https://www.databricks.com/blog/redefining-semantics-data-layer-future-bi-and-ai | [SOURCED] |
| Looker/LookML + Gemini Conversational Analytics | Commercial (Google) | Heavy | Conversational Analytics API grounded in LookML; Google claims LookML cuts GenAI data errors by two-thirds | https://docs.cloud.google.com/looker/docs/conversational-analytics-overview | [SOURCED] |
| Boring Semantic Layer (boringdata + xorq-labs) | OSS, Python/Ibis | **Lightweight/embeddable — MiniML's direct twin** | Explicitly "MCP-friendly," ships example MCP server, any Ibis backend (DuckDB, Snowflake, BigQuery, Postgres…), LLM auto-generates ~80% of model | https://github.com/boringdata/boring-semantic-layer | [SOURCED] |
| Lightdash | OSS + commercial BI | Medium | Open-sourced its YAML semantic layer (dbt-adjacent), "self-fixing" semantic layer with AI | https://www.lightdash.com/blogpost/why-were-building-an-open-semantic-layer | [SOURCED] |
| Honeydew | Commercial (Snowflake Ventures-backed, YC) | Medium (Snowflake Native App) | "Semantic layer for AI and BI," integrates with Snowflake Semantic Views rather than fighting them | https://honeydew.ai/ | [SOURCED] |
| WrenAI (Canner) | OSS GenBI platform | Heavy | Governed text-to-SQL via "open context layer," 20+ sources; actively maintained (engine merged into main repo May 2026) | https://github.com/Canner/WrenAI | [SOURCED] |
| Vanna.ai | OSS → archived | Component library | Text-to-SQL via RAG; **OSS repo archived Mar 2026**, pivoted to commercial Vanna Cloud / 2.0 rewrite | https://github.com/vanna-ai/vanna | [SOURCED] |
| Malloy | OSS language (ex-Google, team now at Meta) | Medium (new DSL) | Semantic model language; adoption limited by learn-a-new-DSL friction | https://docs.malloydata.dev/blog/2023-11-06-beyond-yaml/ | [SOURCED] |
| Zenlytic metrics_layer | OSS Python | Lightweight | YAML metrics → SQL, Snowflake/BigQuery/Postgres/DuckDB — another pre-existing occupant of the "lightweight embeddable" slot | https://github.com/Zenlytic/metrics_layer | [SOURCED] |
| AtScale SML | OSS spec | Spec/standard | Open-source Semantic Modeling Language spec | https://github.com/semanticdatalayer/SML | [SOURCED] |
| metriql | OSS "headless BI" | Medium | dbt-based metrics store from the 2021–22 metrics-layer wave; effectively dormant (see graveyard) | https://github.com/metriql/metriql | [SOURCED] |

### The graveyard
The 2021–2022 "metrics layer" wave already produced a body count, and the causes of death are instructive:
- **Supergrain** — metrics store, pivoted entirely out of the category into marketing automation; its syntax survives only as an alleged influence on dbt metrics ([SOURCED] https://www.supergrain.com/ and https://benn.substack.com/p/metrics-layer).
- **Transform** — acquired by dbt Labs; MetricFlow is its remains ([SOURCED] https://querio.ai/articles/ultimate-comparison-cube-vs-transform-vs-metricflow).
- **metriql** — launched 2022, still on GitHub but no meaningful momentum since the wave broke ([SOURCED] https://github.com/metriql/metriql; exact dormancy date unverified — GitHub API returned 403 [SPECULATION on degree]).
- **Vanna.ai OSS** — 23K stars and still archived in March 2026: even massive community traction in "LLM + SQL" didn't sustain an open-source business, forcing a closed-cloud pivot ([SOURCED] https://pub.towardsai.net/i-turned-an-archived-23k-star-text-to-sql-project-into-a-self-hosted-tool-that-actually-works-out-b08abcb6d0e3).
- The pattern, named contemporaneously: "The metrics layer is dead" ([SOURCED] https://win.hyperquery.ai/p/the-metrics-layer-is-dead). Standalone thin metrics layers die because they're a feature, not a product; the survivors either owned a serving layer (Cube), an ecosystem (dbt), or got absorbed by the warehouse.

### Demand signals
Demand for the *problem* is real and articulate:
- HN thread "Building AI agents to query your databases" (Mar 2025): "Using a semantic layer is the cleanest way to have a human in the loop… a human can validate and create all important metrics… then an LLM can use that metric definition whenever asked"; "LLMs are much more consistent at writing a small JSON vs. hundreds of lines of SQL" ([SOURCED] https://news.ycombinator.com/item?id=43398507).
- dbt's 2026 benchmark: semantic-layer-grounded agents hit 98–100% vs 84–90% for raw text-to-SQL on modeled data, and semantic-layer failures are refusals while text-to-SQL failures are "confident wrong numbers" ([SOURCED] https://docs.getdbt.com/blog/semantic-layer-vs-text-to-sql-2026).
- Academic confirmation of the hallucination-reduction claim ([SOURCED] https://arxiv.org/pdf/2604.25149).
- My targeted Reddit searches for "heavyweight semantic layer" complaints returned nothing indexed [MEASURED — two queries, zero results]; the discontent that MiniML's positioning presumes ("Cube/dbt are too heavy") is not loudly visible in search. The visible demand is for *governed accuracy*, which the platforms now satisfy natively.

### Commercial gravity (people pay for this)
- Cube Cloud: $80/developer/month Premium tier plus consumption pricing ([SOURCED] https://cube.dev/pricing).
- Honeydew: enterprise contract pricing, Snowflake Ventures investment — institutional money says the category is monetizable ([SOURCED] https://www.snowflake.com/en/blog/investment-honeydew-business-intelligence/, https://honeydew.ai/pricing/).
- dbt Semantic Layer is a paid dbt Cloud feature; Vanna monetizes via Vanna Cloud. Money flows to platforms and hosted services — never, so far, to thin MIT-licensed compile-YAML-to-SQL libraries. [SOURCED links above; final clause is the observable pattern]

### Trajectory
"Semantic layer for AI" is unambiguously **growing** through 2025–2026: MetricFlow open-sourced Oct 2025, dbt MCP server launched, Cube repositioned around agents, Snowflake/Databricks/Google all shipped GA semantic-layer features in H1 2026, an Open Semantic Interchange standardization effort exists ([SOURCED] https://davidsj.substack.com/p/open-semantic-interchange), and MCP became the default agent interface to governed metrics ([SOURCED] https://atlan.com/know/mcp/mcp-server-for-dbt/). The category is rising — and consolidating upward into platforms at the same time.

### The hyperscaler test — FAILED (for MiniML)
This is not "about to ship"; it **shipped**:
- Snowflake: Semantic Views GA (standard SQL querying Mar 2, 2026), Cortex Analyst grounded on them, and Semantic View Autopilot *auto-generating* the models ([SOURCED] https://docs.snowflake.com/en/user-guide/views-semantic/overview, https://www.snowflake.com/en/blog/semantic-view-autopilot/).
- Databricks: Unity Catalog Business Semantics GA **and open-sourced**, Genie grounded on metric views ([SOURCED] https://www.databricks.com/blog/redefining-semantics-data-layer-future-bi-and-ai).
- Google: Conversational Analytics grounded in LookML across BigQuery Studio and Looker ([SOURCED] https://cloud.google.com/blog/products/business-intelligence/looker-updates-for-agentic-bi-at-next26).
MiniML supports exactly two dialects — BigQuery and Snowflake — i.e., the two platforms that most completely foreclosed the niche. The residual space (warehouse-agnostic, embeddable, MCP-native, avoid platform lock-in) is real but already occupied by Boring Semantic Layer, dbt MCP, and Cube.

### MiniML's own footprint [MEASURED]
- GitHub dtempx/miniml: **1 star, 0 forks, 0 open issues, 0 watchers**; created 2025-06-09, last push 2026-07-03 (GitHub API, fetched today).
- npm `miniml`: **288 total downloads Jan 1–Jul 2, 2026** — bursty single-digit/low-teen daily spikes consistent with the author's own CI and bot mirrors, not adoption (npm downloads API, fetched today).
- Discoverability: the exact-name npm search does surface the package ([SOURCED] https://www.npmjs.com/package/miniml), but no third-party blog post, thread, or mention of MiniML-the-semantic-layer appeared in any of my 12 searches; the name also collides with the MiniML teaching language. Zero organic footprint. [MEASURED]

## Strongest point FOR the project
The architectural bet is provably right and the category is hot: 2026 consensus (dbt benchmarks, HN, arXiv, every vendor blog) is exactly MiniML's pitch — constrain the LLM to a governed vocabulary and compile to SQL deterministically — and there is a genuine, mostly-unserved sliver for a zero-infrastructure **TypeScript/Node** library (Boring Semantic Layer and Zenlytic are Python; Cube requires a server), in a world where a large share of AI-agent products are built in TypeScript.

## Strongest point AGAINST
The market has already answered, at every altitude, and nobody has heard of MiniML: hyperscalers ship it as a GA checkbox (with auto-generation of the models), dbt/Cube own the warehouse-agnostic MCP path, Boring Semantic Layer owns "lightweight + MCP-friendly" with actual community — while MiniML, 13 months after first commit, has 1 star, 0 forks, ~288 downloads, no MCP server (despite MCP keywords), two dialects, and a public TASKS.md of serious correctness bugs. Vanna's archived 23K-star repo shows that even 1000x MiniML's traction doesn't guarantee survival in this category.

## Viability score: 14/100

## The one question that would change my mind
If MiniML shipped a working MCP server this quarter and I re-ran the footprint check in six months — would it show even ~50 GitHub stars and ~1,000 weekly npm downloads from the TypeScript-agent crowd? That would prove the "lightweight semantic layer for Node/TS agents" sliver actually converts, and I'd revisit upward into the 30s; the market thesis isn't the doubt — distribution is.
