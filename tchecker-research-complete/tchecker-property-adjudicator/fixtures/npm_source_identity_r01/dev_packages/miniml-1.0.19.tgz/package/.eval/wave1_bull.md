# Wave 1 — THE BULL

## Position (2 sentences)
MiniML has near-zero adoption today, but it is a real, working, honestly-documented implementation of a thesis the entire data industry loudly validated in 2025–2026: deterministic semantic layers are the accuracy-and-safety fix for LLM text-to-SQL, and every incumbent solution requires a platform, a server, or a subscription — while MiniML is the only npm-installable library occupying the "embeddable, zero-infrastructure, agent-facing SQL compiler" seat in the Node/TypeScript ecosystem where most MCP servers and AI agents are actually written. The bet is not on the repo's traction (there is none); it is on a validated category, an unoccupied wedge, a live author, and a ~90-day path to a credible MCP-server launch.

## Evidence

**The thesis is now industry consensus, not a hobbyist hunch.**
- [SOURCED] dbt's 2026 benchmark: raw text-to-SQL accuracy of 84–90% jumps to 98–100% when the LLM queries through a semantic layer (Claude Sonnet 4.6: 90.0% → 98.2%; GPT-5.3-Codex: 84.1% → 100.0%). https://docs.getdbt.com/blog/semantic-layer-vs-text-to-sql-2026
- [SOURCED] "Semantic Layer + MCP" is being described as *the* architecture for trustworthy AI analytics; dbt, Cube, and AtScale have all shipped MCP servers for their semantic layers. https://www.polaranalytics.com/post/mcp-semantic-layer-ai-analytics ; https://docs.getdbt.com/blog/introducing-dbt-mcp-server
- [SOURCED] Independent practitioners report ~20% average SQL-accuracy gains from structured validation + schema-aware parsing over raw LLM SQL. https://www.k2view.com/blog/sql-agent-llm/
- This is precisely MiniML's pitch, written in its README a year before the benchmark: LLM picks from a model-defined vocabulary; a deterministic compiler emits the SQL. [MEASURED — README.md lines 3–14]

**The wedge — "library, not platform" — is real and the incumbents cannot follow.**
- [SOURCED] The dbt Semantic Layer's queryable API is a dbt Cloud feature — you cannot self-host it with dbt Core alone. Cube requires operating a server/cluster or paying for Cube Cloud; reviewers cite ongoing pre-aggregation operational burden. https://www.stackfyi.com/guides/semantic-layer-tools-dbt-cube-metricflow-lightdash-2026 ; https://cube.dev/articles/dbt-semantic-layer-alternatives-2026
- [MEASURED] MiniML is `renderQuery(model, options)` → SQL string. No server, no account, no per-query cost. Its alternatives.md is the sharpest artifact in the repo: a correct, honest taxonomy ("headless vs. agentic" semantic models) and a comparison table where MiniML is the only row with "Embeddable as a library: ✅ npm import" (/home/user/projects/miniml/documentation/alternatives.md, lines 16–68). Incumbents structurally cannot match this — their business models *are* the platform.
- [SOURCED] The wedge is being validated in parallel by others: Boring Semantic Layer (boringdata/xorq-labs) launched the same "lightweight, embeddable, MCP-friendly semantic layer" concept in **Python** (Ibis-based) and drew real community attention. https://github.com/boringdata/boring-semantic-layer ; https://juhache.substack.com/p/boring-semantic-layer-mcp — This proves demand for the category, and the **TypeScript/Node seat — the language of the MCP-server and AI-agent ecosystem — is still effectively open.**

**The asset is small but real, and its security story is code, not marketing.**
- [MEASURED] ~1,091 LOC in lib/, of which validation.ts is 323 LOC of AST-based SQL validation via node-sql-parser: dialect-specific function allowlists, blocked DDL/DML/system constructs, comment-pattern blocking, expression-length limits (/home/user/projects/miniml/lib/validation.ts). 68 passing tests concentrated exactly there. For a "safety layer for LLM SQL," having the injection-defense be the *most* tested code is the right shape of investment.
- [MEASURED] End-to-end pipeline works across two dialects (BigQuery, Snowflake); 925-line README with quickstart, API reference, and an honest fan-out warning; TASKS.md openly lists 10 known defects — this is an author who ships truthfully, which is the single best predictor of fixability.
- [MEASURED] The author is active *today*: GitHub `pushed_at: 2026-07-03T15:36:58Z` (the day of this evaluation), after a 9-month dormancy. Apparent production dogfooding at Wayvia (Snowflake conversational analytics) means the library has at least one real workload keeping it honest.

**The brutal numbers (I measured them; the bear will too).**
- [MEASURED] npm: 57 downloads in the last month; the historical daily series shows spikes only on publish days (52, 89, 76, 132, 154…) and near-zero between — i.e., essentially no organic installs, ever (api.npmjs.org, range 2025-06-01→2026-07-01).
- [MEASURED] GitHub: 1 star, 0 forks, 0 open issues, 0 subscribers after 13 months (api.github.com/repos/dtempx/miniml).
- [MEASURED] npm latest is **1.0.16** (Aug 2025) while the repo sits at 1.0.17 — the entire June–July 2026 doc/positioning revival **has not even been published to npm yet**. The "relaunch" hasn't launched.
- [MEASURED] Keywords say "mcp" / "model context protocol" but there is zero MCP code in the repo — the single highest-leverage artifact for this positioning does not exist yet (package.json keywords; no MCP server in tree).
- [MEASURED] Known-defect list includes correctness bugs a first-time evaluator will hit (`date_from == date_to` returns no rows; non-TIMESTAMP date fields generate failing SQL) — TASKS.md lines 1–18. No CI.

**Why the zero-traction number doesn't kill the bull case:** the product was never distributed. No MCP server, no launch post, no Show HN, latest work unpublished, and a name ("miniml") that collides with a classic ML teaching language [MEASURED — dossier caveat; the npm name even has 2018-era squat history in its registry metadata]. Zero marketing in, zero adoption out is not evidence of rejection — the market has literally never seen it. Meanwhile the Python analog with distribution (BSL + MCP blog posts) got traction on the *same idea*. That is the closest thing to a controlled experiment this tribunal will get: the idea sells when shipped to where developers are.

## Strongest point FOR the project
Timing plus an unoccupied structural niche: in 2026 the industry converged on "deterministic semantic layer between LLM and warehouse" as the correct architecture ([SOURCED] dbt benchmark, MCP-server launches by dbt/Cube/AtScale), every credible option requires a platform or a running service, and MiniML is a working, MIT-licensed, npm-installable compiler that already exists in the TypeScript/Node ecosystem where MCP servers are built — with the AST-based injection validation ([MEASURED] lib/validation.ts) that makes the safety claim more than a README sentence. A ~2–4 week effort (ship `miniml-mcp`, publish 1.0.17, fix the two showstopper date bugs, add CI, one launch post) converts this from invisible to testable — the Boring Semantic Layer showed the same play works in Python.

## Strongest point AGAINST
Thirteen months and one star. The measured adoption is not "small," it is zero — 57 npm downloads/month with spikes only on the author's own publish days, no forks, no issues, no external contributor ever — and the author's revival energy so far has gone into README prose rather than the MCP server, bug fixes, or even publishing 1.0.17 to npm. A single part-time author with a 9-month dormancy on record, a colliding name, and correctness bugs in the date path (the most common query in analytics) means the most probable future, absent a deliberate distribution push, is that BSL-style competitors take the "lightweight semantic layer for agents" mindshare in Python while MiniML stays a well-documented personal tool for one company's Snowflake stack.

## Viability score: 58/100
(Read as: the category bet is strong and cheap to test; the current trajectory without a 90-day MCP + launch push would score ~25.)

## The one question that would change my mind
Will the author, within 90 days, ship a working `miniml` MCP server plus the two date-range bug fixes and put it in front of strangers (npm publish + one launch post)? A yes with follow-through moves me to 70+ — it's the exact play that worked for Boring Semantic Layer; a no (or another quarter of README-only commits) means this is dogfood, not a project, and I drop to ~25.
