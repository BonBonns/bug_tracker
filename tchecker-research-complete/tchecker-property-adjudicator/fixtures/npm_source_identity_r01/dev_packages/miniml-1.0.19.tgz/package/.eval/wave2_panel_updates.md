# WAVE 2 — CONSOLIDATED PANEL UPDATES (remaining ten)

Each entry: the strongest opposing claim confronted → steel-man → update or hold with the specific evidence.

---

## PRINCIPAL ENGINEER — hold 34 → **hold 34**
**Confronts the Bull's** "every defect is cheap to fix, so score the ceiling." Steel-man: all my findings (dead AST branch, duplicated null check, join-ref assumption) are 1–10 line fixes; a live author closes them in a day, and then the architecture critique is all that's left, which is prototype-normal. Refutation: cheapness is necessary, not sufficient — the dead-code control shipped and survived 13 months and a dormancy *because nothing forced the fix*, and string-concatenation SQL means each new feature re-opens the correctness surface. Cheap-to-fix bugs that don't get fixed are just bugs. Hold at 34: the code merits a prototype score regardless of whether the market merits a kill.

## SECURITY AUDITOR — hold 28 → **update 26**
**Confronts the Bull's** "the regex layer still protects you, so this is a broken allowlist not an open hole." Steel-man: subqueries/DDL/comments are still blocked; the realistic LLM-emitted-function risk is narrower than "SQL injection." Partly conceded — it's not a wormable RCE. But moved *down* 2, not up: re-reading `dialect.ts`, BigQuery's function surface (EXTERNAL_QUERY for cross-source reads, ML.*, NET.*) is reachable through the dead allowlist, and the denylist is keyword-based, so the residual exposure is larger than my Wave 1 wording implied. A security product selling an allowlist that doesn't run is disqualifying until fixed-and-proven, whatever the regex catches.

## TARGET USER (Maya) — hold 30 → **hold 30**
**Confronts the Bull/Community** "first impression is great, defects are polish." Steel-man: yes, my 5-minute experience was genuinely good and I said so. Refutation: the defects aren't cosmetic — the tool fed my *LLM* instructions (`date_to:null` bypass) that produce wrong results, and the canonical README command errors on copy-paste. "Polish" that makes an agent return confident wrong numbers is the product's core failure mode, not its finish. Hold 30: usable for a reviewed prototype, unshippable for the customer-facing agent it markets to.

## RIVAL (Cube CEO) — hold 20 → **hold 20**
**Confronts the Bull's** "open TypeScript/MCP seat is a real wedge." Steel-man: Cube needs a server, BSL/Zenlytic are Python, so a pure MIT TS library is a genuinely empty cell. Refutation: an empty cell with no occupant *and no traffic* is empty for a reason — we (Cube) ship an MCP server today, BSL has newsletter reach, and the warehouses auto-generate the models. The seat is open because the room emptied. Still doesn't register as a threat; hold 20. (New: the dead-code safety finding means even the one thing I'd have copied — validated freeform WHERE — isn't actually validated as advertised. Nothing to copy this sprint after all.)

## MARKET CARTOGRAPHER — hold 14 → **hold 14**
**Confronts the Contrarian's** "score it as a notation/spec, not a product." Steel-man: OSI, SML, and Databricks open-sourcing semantics prove the format layer is contested, and a good notation can win at 1 star. Refutation: notations win by *distribution* too (dbt's YAML won because dbt had the install base; SML won a seat because AtScale convened vendors). A solo notation with zero footprint and a name collision doesn't enter a standards fight — it isn't in the room. The spec-upside is real but requires the same distribution MiniML measurably lacks. Hold 14.

## MONETIZATION — hold 14 → **hold 14**
**Confronts the Portfolio Manager's** "career capital is a legitimate return." Fully agree — I ranked it #1 myself. No conflict; the disagreement is only whether career capital deserves a *viability* score above the teens, and it doesn't: viability measures the project's forward value, and career capital accrues to the *author* whether or not the project advances. Hold 14, with the same note: a single external paying production user flips open-core from "kill" to "test."

## LICENSE & IP COUNSEL — hold 40 → **update 34**
**Confronts the Security Auditor's** dead-code finding as it bears on *my* domain. Steel-man: license/IP is orthogonal to whether the validator runs. Mostly true — but the README makes affirmative security *representations* ("only safe SQL constructs are permitted") that are now measurably false, which is a latent misrepresentation exposure if anyone adopts it as a security control on those words. Combined with the unresolved Wayvia employer-IP cloud (24/25 commits from a pricespider.com address), moved down 6. The name collision and employer-IP items remain the real gating actions; add "correct or remove the security claims" to the must-fix-now list.

## COMMUNITY ARCHITECT — hold 30 → **hold 30**
**Confronts the Bear/Contrarian** "no-action base rate — polish won't happen." Steel-man: the 9-month dormancy and docs-only revival predict the launch checklist won't get executed either. Concede the risk is real and it's why I'm at 30 not 50. Hold: my brief is a *conditional* — IF the author ships the MCP server and fixes the README, the awesome-mcp-servers (~90k stars) + Show HN path is genuinely open. The distribution machinery works; the question is purely whether the author runs it, which is the tribunal's crux, not mine to resolve.

## AI FUTURIST — hold 31 → **hold 31**
**Confronts the Rival/Cartographer** "hyperscalers foreclosed it." Steel-man: Cortex/Genie/Looker shipped GA semantic layers and auto-generate the models — obsolescence by bundling. Refutation holds my split: platform bundling raises the *obsolescence* risk (I had it at 38) but does not touch the *amplification* thesis — the warehouses building semantic models to ground their LLMs is the strongest possible confirmation that the layer gets *more* valuable as models improve, not less. MiniML's problem was never obsolescence (38, low); it's that its amplification potential (42) is unrealized because the MCP server is a keyword, not code. Hold 31.

## PORTFOLIO MANAGER — hold 32 → **update 30**
**Confronts the Security Auditor's** dead-code finding against my "compounds his day job / production-driven maintenance" thesis. Steel-man: if it's genuinely dogfooded in Wayvia production, that's real value regardless of stars. Partly undercut: a *production-dogfooded* safety layer whose safety control is inert and unnoticed for 13 months suggests the dogfooding is shallow (the freeform-WHERE path may not be exercised in anger, or wrong results went unaudited). Moved down 2 — the "compounds" case rests on the dogfooding being real, and this finding is a small crack in that. Still a near-free option; still archive the ambition, not the code.
