# 13 — Two Questions, Answered Candidly

## Question 1: What did you miss? (ordered by impact)

**1. The Wayvia IP cloud is a campaign blocker, not a legal footnote — and a content plan makes it *worse* until resolved.** 24 of 25 commits are from `dave.templin@pricespider.com` on a library squarely inside Wayvia's line of business (their flagship launch is literally *Wayvia MCP*), while the LICENSE claims personal copyright — "the person granting the MIT license may not actually own the thing he is licensing" (`wave1_license_counsel.md`). Every video, post, and launch this plan produces increases the visibility of that unresolved claim and the awkwardness of resolving it later ("get the waiver in writing *before* the project has value"). The plan gates on it (doc 04, Phase 0 item 6), but the request didn't ask about it, and no channel strategy matters more than this one letter.

**2. You asked for a 12-month plan; the evidence supports a 90-day plan with a conditional tail.** The tribunal pre-committed to a day-90 evidence gate precisely to prevent sunk-cost drift. Building and executing 12 months of content *unconditionally* would re-create the exact failure mode the verdict guards against. The single biggest structural decision in these documents — everything after month 3 is conditional — is a correction to the brief, not a fulfillment of it.

**3. Product truth precedes content, and the current repo fails a 30-second hostile inspection.** The canonical Quick Start errors on copy-paste; the flagship AST safety validator is dead code (`SESSION_USER()` passes); the "mcp" keyword has no code behind it; the auto-generated LLM guidance describes behavior the code doesn't implement. "Discovering this took one probe; a hostile reviewer would close the tab" (`wave1_security_auditor.md`). A launch executed before Phase 0 converts attention into a public, archived record of the gap between claims and code. Marketing amplifies whatever is true — including that.

**4. The most valuable single piece of content is the one the brief would never ask for: the dead-code confession.** "My LLM-SQL safety layer's flagship control never ran for 13 months — here's how tests stay green while a security control does nothing" is a genuinely excellent engineering story, it neutralizes the worst diligence question by answering it first, and it's the only launch asset no competitor can imitate. The repo's honest artifacts (fanout.md, TASKS.md) were the only marketing the panel unanimously praised; this extends the same posture to the worst finding.

**5. The name problem needs a decision, not just awareness.** "miniml" loses search to a lambda-calculus teaching language, an NCBI bioinformatics format, and a UK soap brand (`wave1_license_counsel.md` §4). The plan's default (keep the name, buy the domain, win problem-queries instead of brand-queries) is defensible because every channel here is push- or listing-based — but it's a real decision you should make consciously, and a trademark clearance search belongs before any commercial move.

**6. The highest-EV move isn't content at all: Wayvia sponsorship.** The Portfolio Manager identified formal Wayvia adoption as "the only mechanism visible in the evidence that gets this project distribution and maintenance hours it will never get from nights and weekends." One internal pitch potentially solves the hours constraint, the IP cloud, and the social-proof cold start simultaneously (doc 12 §1).

**7. Fan-out is a product-strategy hole content can't paper over.** The Rival's sharpest attack: MiniML "protects you from SQL injection while letting the LLM-composed query silently return **wrong numbers** — and wrong numbers (not injection) are the failure mode that actually kills chat-with-your-data deployments." The honest-caveat posture is the right *content* answer; a Phase 2 *product* answer (grain declarations + a compile-time fan-out warning) deserves roadmap consideration the brief didn't ask for.

**8. Attribution must be built before launch or the checkpoints are unmeasurable.** GitHub traffic data expires after 14 days; npm can't attribute; launch-week chaos is when you least want to be writing snapshot scripts. Doc 11's instrumentation is Phase 0 work.

## Question 2: Is it all worth it? (the unflattering version)

### The case for

- The thesis is vindicated and the demand is real — problem severity scored 78/100, dbt's benchmark (98–100% vs 84–90%) is the industry's, and even the Bear conceded "if demand existed, this codebase could receive it" (`wave1_bear.md`).
- The TS/MCP-native, zero-infra cell is genuinely empty — Cube needs a server, dbt-mcp needs dbt Cloud, BSL is Python. Nobody disputed the cell is empty; they disputed whether it converts. That's exactly what a cheap test answers.
- The test *is* cheap: ~one 40-hour sprint plus one honest launch, on a codebase whose maintenance is employer-subsidized anyway. And the downside is capped by pre-registered kill criteria.
- Career capital pays on both branches: the writing, the confession post, the pre-registered-criteria discipline, and the retrospective are hireable artifacts whether or not a stranger ever deploys MiniML.

### The case against

- **The market already answered once.** Thirteen months public: 1 star, 0 forks, 0 issues, ~57 downloads/month tracking the author's own publish days. The Bear's framing is fair: "not an early project awaiting discovery… a completed market test that returned a null result" — though the Bull's rejoinder (it was never actually distributed; zero marketing in, zero adoption out) is why the test deserves exactly one real run.
- **The category eats its own.** Vanna had 23,000 stars and still archived. Supergrain pivoted out; Transform was absorbed; metriql went dormant. "Standalone thin metrics layers die because they're a feature, not a product" (`wave1_market_cartographer.md`, graveyard). The survivors owned a serving layer, an ecosystem, or a warehouse — MiniML owns none.
- **The strongest competitor for the exact wedge already has momentum.** Boring Semantic Layer is the same idea, shipped, newsletter-covered, community-backed. The Rival's memo to his own team: "Watch BSL; ignore MiniML."

### The most likely failure mode is you, and the evidence says so

This isn't rhetoric; it's the best-measured finding in the tribunal:

- Your career-best open-source outcome across **three years, six repos, and two ecosystems is 4 GitHub stars** (`wave1_portfolio_manager.md`).
- A **one-line safety fix sat unmade for 13 months, through a 9-month dormancy** — the Contrarian's decisive point: both the kill case and the revival case assume you act, and "the evidence says he mostly *doesn't*… inert is the base rate" (`wave2_contrarian.md`).
- The June 2026 "revival" was **README rewrites and keyword-stuffing, not features** — "marketing effort pointed at a page nobody visits" (`wave1_community_architect.md`).
- Your hours are **executive hours** (Head of Data & AI), allocated in bursts to whatever the day job touches; the Portfolio Manager's specific prediction: "no MCP server unless Wayvia needs one; stars end 2027 in single digits absent a deliberate launch… that his 3-year track record says he won't do."

The plan's structural answers — banked buffers, downgrade rules, pre-registered gates, a 3-video (not 16-video) initial commitment — are engineering around this risk, but no structure survives its operator declining to run it.

### Base rates

For a solo maintainer launching a dev library in a consolidating category: most packages never see 100 organic downloads/week; most Show HNs don't front-page; most solo dev-tool channels stop posting within 6 videos; and the modal outcome of this plan — priced honestly — is **the day-90 gate returning ≤1 of 4 and a dignified archive**. The reconciled viability score is 30/100 *with* "a credible path to the 50s only if the pivot's crux test lights up" (`VERDICT.md`). You should execute this plan expecting the archive branch and be pleasantly surprised, not the reverse.

### The realistic time cost

- Committed (Phases 0–1 + measurement): **~110–130 hours over 13 weeks (8–10 hrs/week)** — every week, including the weeks Wayvia is on fire.
- Conditional (Phase 2): **~250–300 hours over 9 months (6–8 hrs/week)**.
- Worst realistic outcome: ~120 hours spent, criteria missed, project archived with a public post — which still yields the career-capital artifacts. That's the actual bet.

### The conditions under which "yes" holds

1. You can *actually* protect 8–10 hrs/week for 13 consecutive weeks — not on average, not in bursts. If the honest answer is a burst pattern, run the minimum viable version below instead.
2. The Wayvia IP question resolves in writing (or Wayvia becomes the sponsor). Without it, cap investment at Phase 0's code fixes and stop.
3. You accept the pre-commitment — including publishing a miss. If you already know you'd renegotiate the thresholds at day 90, don't start; that's the multi-year sunk-cost path the tribunal convened to prevent.
4. You're willing to publish the uncomfortable material (the confession post). The honest posture is the differentiation; a sanitized version of this plan has no edge.

### The minimum viable version (if those conditions look aspirational)

Cut everything but the crux test, ~60–70 hours total over 10 weeks:

1. Phase 0 code truth + IP letter (weeks 1–2).
2. MCP server + hero GIF + one launch blog post (weeks 3–6). **No video at all** — the GIF carries the demo.
3. One launch: awesome-mcp-servers PR + Show HN + dbt Slack + the two verified newsletters, in one week (week 7).
4. Respond to everything for three weeks; run the snapshot script (weeks 8–10).
5. Measure the four criteria at day 90 and honor them.

This version answers the same question for roughly half the hours, sacrificing only the compounding tail (which was conditional anyway) and some career-capital content (recoverable later — the writing can always be done after the evidence exists). **If even this feels heavy, the honest move is the Bear's:** keep the code as Wayvia tooling, skip the campaign, and lose nothing you measurably have today.

### Bottom line

Worth it **once, bounded, and instrumented** — because the question is real, the test is cheap, the downside is a dignified archive plus portfolio-grade writing, and the upside (an empty cell in a validated category, plus the option Wayvia sponsorship represents) is genuinely asymmetric. Not worth it as an open-ended growth campaign — the evidence against that was gathered over 13 months, by you, and it is unambiguous.
