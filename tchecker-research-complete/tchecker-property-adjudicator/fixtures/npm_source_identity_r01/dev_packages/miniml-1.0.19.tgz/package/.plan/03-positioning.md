# 03 — Positioning: One Sentence, Load-Bearing Claims, and the Hardest Questions

## The one-sentence position (sharp enough to be wrong)

Adopt the tribunal's positioning verbatim — it was written to be falsifiable:

> **"For TypeScript engineers building AI agents that query data, MiniML is the only zero-infrastructure, warehouse-agnostic semantic layer that installs as an npm package and speaks MCP natively — no server, no platform, no vendor lock-in."** (`VERDICT.md` §1)

What makes it sharp: "This deliberately abandons the 'better than Cube/dbt on Snowflake' framing (a fight against native vendor features) and stakes the one empty cell: *embeddable + TS + MCP-native*. It is falsifiable — if TS agent-builders don't want a library-shaped semantic layer, this positioning fails fast, which is the point."

**Honesty constraints on using this sentence:**

- "Speaks MCP natively" is **false until the MCP server ships.** The current state — "mcp" as an npm keyword with zero MCP code — was flagged by *every single panelist* and is the pattern ("present-in-claim, absent-in-execution") that cost the Bull 16 points (`wave2_bull_rebuttal.md`). No content uses this sentence before Phase 1 week 5.
- "Warehouse-agnostic" is generous at two dialects. Until Postgres ships (`05-database-support.md`), say "BigQuery and Snowflake today, dialect-based by design."

## The 3 load-bearing claims (each defensible under hostile scrutiny)

### Claim 1 — Deterministic compilation beats raw text-to-SQL, and the gap doesn't close as models improve.

- dbt's 2026 benchmark: 98–100% accuracy through a semantic layer vs 84–90% raw; failures through the layer are *refusals*, raw failures are "confident wrong numbers" (`wave1_market_cartographer.md`). Spider 2.0 enterprise leader at ~36% vs ~86% on toy schemas; Snowflake measured GPT-4o at 51% on real BI questions, +20% with a semantic model (`wave1_ai_futurist.md`).
- Strongest hostile rebuttal: "models will get better." Answer: dbt's own paired data — raw improved 32.7%→64.5% as models improved while layered stayed ~100%; "reliability requires a compiler that enforces the patterns, not a model that may or may not follow them." Every hyperscaler *built the layer* rather than betting on model improvement (`wave1_ai_futurist.md`, obsolescence verdict).
- This claim is the industry's, not MiniML's — which is exactly why it's safe to lean on.

### Claim 2 — MiniML is the only way to get that architecture as a pure library in the TypeScript/Node ecosystem: no server, no account, no platform.

Steelman the competitors honestly (this table is the hostile-scrutiny version, not the marketing version):

| Alternative | Their genuine strength | Why the claim survives |
|---|---|---|
| **Cube** | Real join-graph + fan-out protection, caching, RLS, dozens of engines, a *shipping* MCP server, 20k+ stars. The Rival's counter-pitch (`wave1_rival.md`) is largely accurate. | It's a server you operate (or Cube Cloud you pay for). For an engineer embedding one governed vocabulary into one agent, that's a platform adoption, not a dependency. "Cube minus the server" is the honest shorthand — and Cube structurally can't follow ("their business models *are* the platform," `wave1_bull.md`). |
| **dbt Semantic Layer / dbt-mcp** | The install base; MetricFlow rigor; official MCP server with the exact toolset. | The queryable API is dbt-Cloud-gated; adoption presumes the dbt toolchain. Maya doesn't have a dbt project. |
| **Boring Semantic Layer** | The direct twin, MCP-friendly, multi-engine via Ibis, real community momentum. The most dangerous comparison because it's the same idea, executed and distributed (`wave1_rival.md`: "If a lightweight compiler ever eats our low end, it will be BSL-shaped"). | It's Python. The claim is scoped to TS/Node — where most MCP servers and agents are written — precisely because BSL owns the Python cell. Never pretend otherwise. |
| **Snowflake Cortex / Databricks Genie / Looker+Gemini** | Native, GA, free-with-platform, and they *auto-generate* the models (Semantic View Autopilot). | Platform-bound and agentic (LLM in the query path, non-deterministic). If you're all-in on one warehouse, use them — that's anti-audience #2. The claim survives only for multi-warehouse, embedded, or lock-in-averse cases. |
| **Drizzle Cube** | TypeScript, ships MCP endpoints (`wave1_ai_futurist.md`). | Server-framework-shaped and ORM-coupled. Closest TS neighbor; watch it, name it when asked, differentiate on "pure library, plain-YAML models you own." |

### Claim 3 — MiniML safely accepts *freeform* WHERE/HAVING SQL from an untrusted LLM — validated against an AST allowlist and the model's own vocabulary — which neither dbt-mcp nor BSL attempts.

- The AI Futurist: "a defensible design point for agent use — and it's where 68 of its tests live." The Rival listed it first among things Cube would copy.
- **This claim is currently false in the shipped code** — the AST validator is dead code; `SESSION_USER() = revenue` passes (`wave1_principal_engineer.md`, `wave1_security_auditor.md` Finding 1). It becomes usable only after: the one-line fix at `validation.ts:280`, a regression test that *asserts the allowlist blocks a non-allowlisted function*, and a 100+-expression red-team corpus running in CI (the Security Auditor's explicit re-scoring condition). Until then, README security claims must be corrected or removed — License Counsel flagged the current text as "latent misrepresentation exposure" (`wave2_panel_updates.md`).
- Once true, this is the *most differentiated* claim of the three — and the confession-and-fix story is itself the strongest single piece of launch content (see `07-x-twitter-plan.md` week 1).

## The hardest diligence questions — rehearsed one-breath answers

**Q1 (the hardest): "Your flagship safety validator was dead code for 13 months and your tests never noticed. Why should I trust anything this library claims?"**

> "You shouldn't have — that's why I found it, fixed it, and published the write-up. The allowlist now runs, there's a regression test asserting a non-allowlisted function is rejected, and a red-team corpus of hostile WHERE/HAVING expressions runs in CI on every commit. The lesson cost me a year: tests must assert the control *runs*, not just that bad input fails. Check the corpus yourself — it's in the repo."

(Do not launch until every sentence of that answer is literally true. The Principal Engineer's test — "does the author treat a red result as a five-minute fix… or does it sit?" — is being asked publicly the moment this goes to HN.)

**Q2: "Snowflake auto-generates semantic models natively. Why do you exist?"**

> "If you're all-in on Snowflake, use Cortex — genuinely. MiniML is for the app builder embedding analytics into their own product or agent: your models are plain YAML you own, the compile is deterministic and auditable, it runs anywhere Node runs, and nothing about your data or metadata flows through a vendor. Different job."

**Q3: "One author, one star, a nine-month dormancy on record. Will this exist in a year?"**

> "It's ~1,000 lines of MIT TypeScript you can read in an afternoon and fork in a minute — the bus-factor risk is bounded by the size. It's maintained because my employer runs it in production, so the maintenance is funded whether or not it's popular. And I've published pre-registered criteria for what I'll do at day 90 — you can hold me to them."

(The third sentence is only available because this plan pre-registers the criteria publicly — see `11-metrics-kill-criteria-and-fallback.md`. The second sentence requires the Wayvia situation to be resolved and acknowledgeable — see `04-prerequisites-and-sequencing.md` §Phase 0.)

**Q4: "What about fan-out? Your own docs admit revenue can silently double."**

> "Correct, and it's documented on page one of the caveats, not buried: MiniML compiles the joins you wrote and does not rewrite aggregates. The mitigation is modeling discipline — one model per grain — and the docs show exactly how. If you need symmetric aggregates enforced by the engine, that's Looker or Cube, and I say so in the comparison doc."

(This is the Rival's strongest product attack — "it protects you from SQL injection while letting the LLM-composed query silently return wrong numbers" (`wave1_rival.md`). There is no rhetorical escape; the only defensible posture is the one `fanout.md` already takes. A roadmap answer — grain declarations with a compile-time warning — is worth considering in Phase 2, but do not promise it in content.)
