# 09 — Other Platforms: HN, Ecosystem Surfaces, Blog/SEO, LLM Presence, LinkedIn, Podcasts — and What We Skip

## Hacker News (the launch centerpiece — one shot, done right)

- **Timing:** Day 1 of launch week (Tue–Thu, ~9:00 ET), the day after the awesome-mcp-servers PR.
- **Title** (refined from the two drafts in `VERDICT.md` §3 and `wave1_community_architect.md`): *"Show HN: MiniML – a small semantic layer so your LLM never writes raw SQL."*
- **First comment** (author-posted): the Community Architect's draft, updated to be true post-Phase-0 — leads with the problem ("letting an LLM generate free-form SQL was a recurring source of wrong numbers"), the mechanism (vocabulary → deterministic compile), the honest caveats (fan-out, two dialects), and *the dead-code confession with the fix* — pre-empting the one probe a hostile reviewer would run (`wave1_security_auditor.md`). Ends with a real question: "what dialect do you need next?"
- **Reality check:** most Show HNs don't front-page; the plan does not depend on it (see success math, doc 01). If it flops, the launch blog post gets one ordinary submission 4–6 weeks later; no resubmission games.
- **Prerequisite gate:** HN fires only when README commands run verbatim and the security claims are true — "HN will click the repo within 30 seconds" (`wave1_community_architect.md` #2).

## Ecosystem surfaces (highest qualified-visitor yield per hour — Day 0 work)

| Surface | Action | Basis |
|---|---|---|
| **punkpeye/awesome-mcp-servers** (~90k stars) | PR on launch Day 0 — "Highest-leverage single listing for this project's stated positioning," gated entirely on the MCP server existing | `wave1_community_architect.md` #1 |
| **MCP registries: PulseMCP, mcp.so** (+ Anthropic's registry as available) | List with the demo GIF; "agents discover tools via MCP registries… an unshipped keyword is invisible" | `wave1_ai_futurist.md` |
| **GitHub topics** | Set `semantic-layer`, `mcp`, `text-to-sql`, `bigquery`, `snowflake` — repo currently has **none**; no awesome-semantic-layer list exists, the topic page is the substitute | `wave1_community_architect.md` #1 |
| **npm** | Publish current state (npm still serves 1.0.16 — the "relaunch" never launched, `wave1_bull.md`); keywords finally made honest by the MCP server |
| **Newsletters** | **Data Engineering Weekly** (verified active, covers exactly this beat — Lyft YAML metric layer, Netflix DataJunction) and **Ju Data Engineering** (lightweight/zero-infra angle). Pitch the *artifacts* — the fan-out doc and the security post-mortem — "not the project itself." **TLDR Data could not be verified — do not plan around it.** | `wave1_community_architect.md` #6 |

## Blog + SEO (the owned center — every other channel's raw material)

- **Buy `miniml.dev` (or similar); GitHub Pages; docs + blog.** Purpose: attribution short links, the name-collision workaround (License Counsel §4: plain "miniml" search surfaces soap refills, an NCBI format, and PL-course repos), and a home for content LLMs can cite.
- **SEO strategy: target problem queries, never the brand.** The dossier's five stranger-search phrases are the literal keyword list: "lightweight semantic layer for text-to-SQL," "LookML alternative open source YAML," "safe SQL generation for LLM agents," "embeddable metrics layer node.js," "MCP server semantic layer Snowflake BigQuery."
- **Cadence: every video ships its script as a post** (the twin system, doc 06) — no separate blog workload. Plus three cornerstone pieces that exist independent of video: the launch post ("Why we put the LLM *outside* the SQL path" — `VERDICT.md` §3), the security post-mortem, and the fan-out explainer (already ~written as `fanout.md`).

## Presence in LLM answers (a real discovery channel, deliberately engineered)

Maya's search now happens inside Claude/ChatGPT/Cursor as often as Google. The VERDICT names this explicitly: "add an `llms.txt` and ensure the model-card generator output is clean prompt material. **Projects legible to agents get discovered by agents**" (§4). Actions:

1. `llms.txt` + `llms-full.txt` on the docs domain; README structured as answerable Q&A (what is it / when to use / when NOT to use / quickstart).
2. Get into the surfaces LLMs retrieve from: awesome-lists, registries, the GitHub topic pages, Stack Overflow answers (below) — listing presence is training/retrieval presence.
3. The steelmanned `alternatives.md` is already ideal LLM fodder (a balanced comparison table is exactly what assistants quote); keep it current and hosted on the domain too.
4. **Measure it:** monthly, run 5 canned prompts ("how do I safely let an LLM query Postgres from Node?", the dossier's phrases) against Claude/ChatGPT/Perplexity; log whether MiniML appears. It's a lagging indicator, but it's the channel's only scoreboard.

## LinkedIn (the career-capital channel — buyers and the author's market live here)

- This is where the *goal that pays* (doc 01) gets banked: the author is Head of Data & AI; the audience is data leaders, recruiters, and consulting buyers — "Value requires writing/talks, not more commits" (`wave1_monetization.md`).
- **1 post/week, repurposed** (the X thread rewritten in prose; the video embedded), framed for leaders: accuracy benchmarks, build-vs-buy, governance of AI analytics. Zero extra content creation — repackaging only (~30 min/wk).
- Expectation honesty: LinkedIn converts to *opportunities for Dave*, not installs. That's the point.

## Podcasts + talks (Phase 2 only)

No story exists until the crux resolves. Post-gate, with real numbers in hand: pitch data-eng podcasts (e.g. the Data Engineering Podcast, which profiles niche OSS) and AI-agent/MCP shows; submit 1–2 CFPs (local meetups first — a recorded meetup talk is the podcast audition). The pitch is the *journey* ("pre-registered kill criteria for my own open-source project — and what the data said"), which is interesting even to audiences that will never use MiniML. ~4 hrs per appearance; cap at 1/month.

## Stack Overflow (opportunistic only)

No question volume exists for a 1-star brand — do not "seed" questions (transparent and bannable). Instead: answer existing questions on text-to-SQL safety, MCP config, and semantic-layer patterns generically, linking MiniML only where it's honestly the answer. ≤30 min/week, skippable. Value is partly the LLM-retrieval presence above.

## Deliberately skipped, and why

| Platform | Why skipped |
|---|---|
| **Product Hunt** | Audience is prosumer/founder hunters, not warehouse-owning TS engineers; a no-signup dev library gets a badge and no qualified traffic. The hour goes to the awesome-list PR instead. |
| **TikTok / Shorts / Instagram** | ICP absent; production cost pattern is exactly the abandonment risk doc 06 defends against. (YouTube Shorts *cuts* of existing clips are fine — zero marginal cost — but no native short-form program.) |
| **Bluesky / Mastodon / Threads** | Mirror posts if trivial via a cross-poster; no native effort. Data-eng presence exists but is thin for this ICP; a solo operator can't tend four microblogs. |
| **Discord server (own)** | Not skipped — deferred behind a pre-committed threshold. See `10-community-space.md`. |
| **Paid ads (Google/Reddit/X)** | Wrong currency: budget is hours not dollars, ICP is ad-blind, and there's no revenue to recover CAC against (`wave1_monetization.md`). |
| **Conference talks in months 1–6** | CFP lead times exceed the 90-day gate; committing before the gate violates the pre-registration logic. |
| **Medium/dev.to as primary** | Canonical content lives on the owned domain (attribution + SEO equity); syndicate with canonical tags only if free minutes exist. |
