# 01 — The Business Goal and the Success Math

## The stated goal vs. the real goal

The stated goal of a "content and evangelism plan" is growth: stars, downloads, users. The honest goal, grounded in the tribunal, is different, and this plan is built around the honest one.

**The evidence:**

- Direct revenue potential is "~2/100" — "the only non-fantasy return is career capital plus a long-shot 'strategic asset' option, and both are maximized by the same action: keep it MIT, make it excellent, and **market the author rather than the package**" (`wave1_monetization.md`).
- The verdict is **PIVOT with a pre-committed 90-day evidence gate**, not "grow": "run one cheap, time-boxed, kill-criteria-gated pivot… and let 90 days of pre-committed evidence decide" (`VERDICT.md`, Executive Verdict).
- Three independent panelists — Bear, Rival, Monetization — each named the *same* single question as the thing that would change their mind: **one external production user who is not the author's employer.**

### [BUSINESS GOAL] — stated explicitly

> **Primary goal: produce a definitive, evidence-based answer — within 90 days of launch — to the question "will one non-author organization put MiniML into production?" (the tribunal's crux), while banking career capital for the author that pays regardless of the answer.**

This is deliberately *not* "get 10,000 stars" or "build a business." The prize structure is:

| Outcome | What it's worth |
|---|---|
| **Crux passes** (≥1 external org adopts) | The project earns Phase 2: a real public future, escalation toward DOUBLE DOWN, revived monetization options ("a single external paying production user flips open-core from 'kill' to 'test'" — `wave1_monetization.md`) |
| **Crux fails** | A clean, pre-committed archive of the *ambition* (not the code), zero further spend, and no years of sunk-cost drift (`VERDICT.md` §6) |
| **Either way** | Career capital: "+$10–40k/yr in salary leverage or 1–2 consulting engagements ($150–250/hr) IF paired with content and adoption push" (`wave1_monetization.md`, Path 1). The content *is* the mechanism: "at 1 star it's a portfolio piece, not a reputation. Value requires writing/talks, not more commits." |

**The real prize is not GitHub stars and it is not customers (there is nothing to sell). It is (a) a decisive answer, cheaply, and (b) the author's reputation as the person who thought clearly about governed LLM→SQL — which the Monetization brief identifies as the only path that pays at current traction.**

## What a win costs and pays

**Cost (see `04-prerequisites-and-sequencing.md` for the breakdown):**

- Phase 0 + Phase 1 (the 90-day sprint + launch + measurement): **~110–130 hours over 13 weeks, i.e. 8–10 hrs/week.** This matches the VERDICT's estimate: "roughly one 40-hour sprint plus one honest launch," plus the content wrapper this plan adds.
- Phase 2 (months 4–12, **conditional on the gate**): ~6–8 hrs/week, ~250–300 additional hours.
- Cash: a domain (~$20/yr), a decent USB mic if not owned (~$100), nothing else. No paid ads — the ICP is ad-blind and the budget currency here is hours.

**Pays (expected value, honestly):**

- Career capital is near-certain if the content ships, even on a failed crux (the writing survives the project).
- External adoption is genuinely uncertain — the panel split exactly here: "The cell is genuinely empty (Cube needs a server; BSL/Zenlytic are Python), but nobody produced evidence it *converts* — only that it's unoccupied" (`VERDICT.md`, disagreement map).

## The smallest success that matters

**One identifiable external organization running MiniML's MCP server in a real workload within 90 days of launch.**

Not 75 stars (that's an amplification proxy), not a viral HN thread. One stranger's production deployment is the datum that: flips the Bear ("Zero-to-one on that single axis would force me to re-price everything"), flips the Rival ("this stops being a personal tool with a great README and becomes the seed of the 'SQLite of semantic layers'… I would rescore to 45–55"), and revives monetization paths from "kill" to "test."

## The success math: how many of *whom*

Work backwards from 1–3 external production adoptions:

| Funnel stage | Count needed | Basis |
|---|---|---|
| Production adoptions | 1–3 | The crux |
| Serious evaluations (a "Maya" spends 30+ min, wires it into an agent) | 20–40 | ~10% eval→adopt; Maya's brief shows conversion is decided in the first 30 minutes by *product truth* (does the Quick Start run verbatim, does single-day query work), not by marketing (`wave1_target_user.md`) |
| Installs / trials | 200–400 | ~10% install→serious eval |
| **Qualified** repo visitors (TS engineers actually building agent/data features) | 2,000–4,000 | ~10% visit→install for a well-matched dev tool with a working quickstart |
| Raw impressions across channels | 30,000–60,000 | qualified-visitor yield varies wildly by channel — see below |

**This math is satisfiable by the launch window alone.** A front-page Show HN delivers roughly 20k–50k views; the awesome-mcp-servers listing (~90k stars, verified active — `wave1_community_architect.md` #1) delivers a smaller but *perfectly qualified* evergreen trickle; the two verified newsletters (Data Engineering Weekly, Ju Data Engineering) deliver a few thousand exactly-right readers. The 12 months of content in this plan is **not needed to hit the crux number** — it exists to (a) keep the funnel filled in Phase 2 if the crux passes, and (b) build the author's reputation, which pays either way.

### Optimize for who, not how many

The binding constraint is **qualified** visitors: TypeScript engineers, currently building an AI agent that touches a database, allergic to running infrastructure (the ICP in `02-audience-and-icp.md`). Concretely:

- 500 readers from awesome-mcp-servers ≫ 20,000 generic r/programming readers (which the Community Architect explicitly says to avoid — the name collision with the ML teaching language "invites derailment").
- The March 2025 HN thread the Market Cartographer found ("Using a semantic layer is the cleanest way to have a human in the loop…") is a literal roster of pre-qualified people articulating MiniML's pitch in their own words. Those ~dozens of commenters are worth more than any impression count — they're the direct-outreach list in `12-non-content-paths.md`.

## The conversion surface (where the funnel ends)

- **Primary: the GitHub README** — specifically a "Connect your agent in 5 minutes" MCP quickstart anchor at the top, under the hero GIF. Every channel points here.
- **Secondary: a one-page docs site on an owned domain** (see `09-other-platforms.md`) — exists mainly for attribution (per-channel short links, since GitHub referrer data is lossy and 14-day-windowed) and to mitigate the name-collision search problem (`wave1_license_counsel.md` §4).
- **No email list in Phase 1.** For a solo operator it's another surface to keep alive; "Watch releases" on GitHub is the interim subscribe mechanism. Revisit at the month-6 checkpoint.
- **Attribution:** weekly snapshot script (GitHub API + npm API + traffic referrers → CSV, cron), per-channel short links, and a "How did you find MiniML?" field in the issue template. Details in `11-metrics-kill-criteria-and-fallback.md`.
