# MiniML — Content & Evangelism Plan

**Plan in one paragraph:** This is a conditional, evidence-gated evangelism plan built directly on the `.eval/` tribunal's PIVOT verdict, not a conventional growth campaign. The real business goal is to decisively answer the tribunal's crux — *will one non-author organization put MiniML into production within 90 days of a real MCP server shipping?* — while banking career capital that pays regardless of the answer. Phase 0 (2 weeks) fixes the truth debt nothing can launch over: the dead-code AST validator, the broken Quick Start, the false security claims, and the Wayvia IP cloud. Phase 1 (weeks 3–13) ships the MCP server (the wedge, hero demo, and awesome-list ticket in one artifact), a template gallery, and exactly one properly-sequenced launch into verified channels (awesome-mcp-servers, Show HN, dbt Slack, Data Engineering Weekly), wrapped in a lean content layer (3 videos, a 12-week X calendar, value-first Reddit posts). At day 90 the tribunal's four pre-registered criteria decide — publicly, with no renegotiation — whether Phase 2 (months 4–12: full YouTube cadence, the strategically critical Postgres dialect, outreach, podcasts, an armed-but-not-fired Discord threshold) runs at ~6–8 hrs/week, or whether the ambition is archived cleanly while the code lives on as near-free Wayvia tooling. Total committed cost: ~110–130 hours over 13 weeks at 8–10 hrs/week; everything beyond that is earned by evidence, not hope.

## The documents

| Doc | Contents |
|---|---|
| [01 — Goal & Success Math](01-goal-and-success-math.md) | The honest business goal (a decisive crux answer + career capital, not stars or revenue), what a win costs and pays, the smallest success that matters, the funnel math, and the conversion surface |
| [02 — Audience & ICP](02-audience-and-icp.md) | Conversion target ("Maya") vs. amplification audience, where each actually lives, ICP qualifying axes, and the anti-audience that builds credibility by being turned away |
| [03 — Positioning](03-positioning.md) | The one-sentence position, 3 load-bearing claims with steelmanned competitors, and rehearsed one-breath answers to the four hardest diligence questions |
| [04 — Prerequisites & Sequencing](04-prerequisites-and-sequencing.md) | Phase 0 truth debt → Phase 1 sprint & launch → the day-90 gate → conditional Phase 2; what must exist before anything goes public; effort table |
| [05 — Database Support](05-database-support.md) | Why dialects are the strategic escape from the foreclosed BigQuery/Snowflake position: Postgres (critical, month 4–5), DuckDB (month 6), MySQL/Redshift (demand-driven), MSSQL/Spark (skip) |
| [06 — YouTube](06-youtube-plan.md) | 16 videos across 12 months, titles written as search queries, basic→hardest progression, artifact per video, banked buffer + batch production + pre-authorized downgrade rule |
| [07 — X/Twitter](07-x-twitter-plan.md) | Voice (receipts + radical honesty), content mix, a concrete 12-week calendar keyed to the sprint, and the recurring per-video system |
| [08 — Reddit & Forums](08-reddit-and-forums.md) | Community order (dbt Slack, MCP Discord, r/dataengineering, r/LocalLLaMA…), rules of engagement, and pre-committed post disqualifiers |
| [09 — Other Platforms](09-other-platforms.md) | Show HN plan, ecosystem surfaces (awesome-mcp-servers, registries, topics), blog/SEO on an owned domain, LLM-answer presence, LinkedIn, podcasts — and what's deliberately skipped |
| [10 — Community Space](10-community-space.md) | Why not Discord now (empty-room evidence), GitHub Discussions as interim, a four-part pre-committed launch threshold, and the rollout + shutdown rules |
| [11 — Metrics & Kill Criteria](11-metrics-kill-criteria-and-fallback.md) | Instrumentation, the day-90/month-6/month-12 checkpoints with decision rules in the currency of the goal, the vanity-metric ban, and the archive-with-dignity fallback |
| [12 — Non-Content Paths](12-non-content-paths.md) | Wayvia sponsorship (the highest-leverage move in the plan), 25-target concierge outreach, ecosystem partnerships/OSI — and how content multiplies each |
| [13 — Candid Assessment](13-candid-assessment.md) | What the brief missed (ordered by impact) and the unflattering is-it-worth-it: base rates, the author-as-risk-factor evidence, conditions for "yes," and a ~60-hour minimum viable version |

## Key decisions this plan asks you to make

1. **Accept the conditional structure.** Everything after day 90 is gated on the tribunal's four pre-registered criteria — including this plan's own YouTube schedule. If you intend to keep going regardless of the numbers, say so now and read doc 13 first.
2. **Resolve the Wayvia IP question in writing before launch** (doc 04 Phase 0 / doc 13 miss #1) — and decide whether to pair it with the sponsorship pitch (doc 12 §1), which is the single highest-leverage move available.
3. **Adopt the kill criteria verbatim and publicly** (doc 11), including publishing the day-90 result on a miss.
4. **The name:** keep `miniml` + buy the domain (the plan's default), or rename before spending content effort on a colliding brand (doc 13 miss #5).
5. **Commitment level:** full plan (8–10 hrs/wk × 13 weeks) or the minimum viable version (~60–70 hrs, no video, doc 13) — chosen honestly against your actual availability pattern, which the evidence says is burst-mode.
6. **Publish the dead-code confession** as the launch's centerpiece content (docs 03/07/13 §4) — the plan's credibility strategy depends on it.
7. **DCO + CONTRIBUTING before the first external PR** (doc 04 item 7) — preserves the relicensing option that closes permanently at the first merged stranger's patch.
8. **Postgres as the first post-gate feature** (doc 05) — confirm you're willing to fund the `dialect.ts` refactor + per-dialect validation corpus (~50–70 hrs total) if Phase 2 fires.
