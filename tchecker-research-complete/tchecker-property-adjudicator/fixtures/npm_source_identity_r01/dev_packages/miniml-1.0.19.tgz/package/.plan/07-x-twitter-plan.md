# 07 — X/Twitter: Voice, Mix, First 12 Weeks, Recurring System

## Role in the funnel

X is **not** a conversion channel for this ICP — it's (a) the build-in-public record that makes the launch legible ("who is this person and are they for real?" is answerable by scrolling), (b) the relationship surface with the amplification audience (MCP builders, data-eng writers, newsletter editors), and (c) raw material for the career-capital goal. The Portfolio Manager found "a Twitter account (twitter.com/davetemplin) with no discoverable miniml promotion" — the account exists; the record doesn't. Expect single-digit engagement for weeks; the point is the archive, not the reach.

## Voice

**A practicing engineer showing receipts, with the repo's own signature trait: radical honesty.** The panel's only unanimous marketing praise was for the honest artifacts (fan-out warning, committed bug list, steelmanned alternatives.md). The voice rules:

- Show terminal output, SQL, diffs, graphs — never stock imagery or "🚀 excited to announce."
- Steelman competitors by name (Cube, dbt-mcp, BSL, Cortex); recommend them to the anti-audience publicly.
- Publish the uncomfortable numbers. A "13 months, 1 star, here's what I'm doing about it" post outperforms any growth-hack because it's the only kind of post nobody else in the category can write.
- No engagement bait, no reply-guy tactics, no threads that end in "follow for more."

## Content-type mix (steady state)

| Type | Share | Example |
|---|---|---|
| Teaching snippets (SQL, semantic-layer, MCP mechanics) | 40% | "Your LLM writes `COUNT(*)` after a one-to-many join. Here's the silently-wrong number it returns, and why." |
| Build-in-public progress (receipts: diffs, tests, metrics) | 25% | CI screenshot: "the allowlist regression test that should have existed 13 months ago, now green" |
| Demo clips (≤60s cuts from videos/GIFs) | 15% | The hero loop, cut to 40 seconds |
| Category commentary (OSI, vendor launches, benchmarks) | 10% | "dbt's 98% vs 84% benchmark, and what it doesn't say" |
| Replies/community (MCP + data circles) | 10% | Substantive answers in threads where people describe the problem |

Cadence: **3–4 posts/week + 10 min/day of replies ≈ 2 hrs/week.** Sustainable floor (pre-authorized downgrade): 1 post/week + launch weeks. Batch-write Mondays.

## The first 12 weeks (keyed to the Phase 0/1 sprint calendar in doc 04)

| Week | Sprint context | Post concepts (concrete) |
|---|---|---|
| 1 | Phase 0: fixing truth debt | **The confession thread (the opener):** "I built an AST-based SQL safety validator for LLM queries. Last week I discovered it never ran — dead code for 13 months, tests green the whole time. Thread on how that happens and what it taught me about testing security controls." Ends with the fix diff. This is the single highest-credibility post available to the project — it converts the tribunal's worst finding into its best content. |
| 2 | Phase 0 wrap | Receipt post: CI badge green + the `SESSION_USER()` regression test. Second post: "Fixed the bug where my docs told the LLM `date_to: null` bypasses the default range — and the code ignored it. If your tool generates instructions for an AI, test that the instructions are *true*." (Maya's step 8, as a lesson.) |
| 3 | MCP server dev starts | Dev-log: "The entire MCP server is ~200 lines because the library already speaks the right shapes: list_models, get_model_info, render_query." Screenshot of tool definitions. |
| 4 | MCP server | "What my LLM sees" post: the auto-generated model card (`npx miniml sales.yaml` output) side-by-side with the YAML. "The model is 40 lines. The prompt material writes itself." |
| 5 | MCP server done | First demo clip: Claude Desktop asks, MiniML answers — raw, unedited, 45 seconds. "No server. No platform. `npx miniml mcp sales.yaml`." |
| 6 | Assets week | Fan-out teaching thread (the `fanout.md` orders/line_items example with real numbers: "this query returns $1.2M; the right answer is $400k; no error was raised"). |
| 7 | Assets week | Template gallery preview: the Stripe model YAML in one screenshot. "Fork it, point it at your Stripe schema, connect your agent." |
| 8 | Hero video ships | V1 drop + the GIF. Pin the post. |
| 9 | **Launch week** | Day 1: Show HN link with one-line context (no begging). Same day: the launch blog post. Days 2–5: respond publicly to the best HN/Reddit questions as posts ("Best question from yesterday: 'what about fan-out?' — honest answer:"). |
| 10 | Post-launch | **Launch retro with real numbers:** traffic, stars, installs, what flopped. "Optimize for who, not how many — 300 visits from awesome-mcp-servers beat 8,000 from HN. Here's the breakdown." |
| 11 | Response mode | Benchmark commentary thread (dbt 2026 numbers + Spider 2.0) — written to be quotable by the newsletter editors watching. Second post: first external issue/PR, celebrated loudly (social proof of life). |
| 12 | Approaching gate | "In 3 weeks I measure this project against 4 criteria I pre-registered before launch. Here they are. I'll publish the result either way." (This post makes the kill criteria credible — and makes quiet-fade impossible, which is the point.) |

## The recurring system (Phase 2, keyed to the video schedule)

Per monthly video: **1 clip (≤60s) + 1 thread (the video's core argument in 6–8 posts) + 2 standalone snippets (the two best single frames/examples)** — scheduled the same day the video ships, ~1 hr of extraction work. Plus: one metrics-transparency post per month (the checkpoint ledger), and category commentary opportunistically. Every post that shows the product links `miniml.dev/x` (attribution).

**What X will not do here:** replace the launch (HN/awesome-lists convert; X doesn't), or reach the Maya who isn't on X (most aren't — which is why this channel gets 2 hrs/week, not 10).
