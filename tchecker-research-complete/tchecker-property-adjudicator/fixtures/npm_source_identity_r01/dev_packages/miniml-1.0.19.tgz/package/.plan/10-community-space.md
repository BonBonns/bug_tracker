# 10 — A Dedicated Community Space: The Empty-Room Decision

## Recommendation: **not now.** GitHub Discussions is the interim home; Discord launches only when a pre-committed threshold fires.

## The real benefits (why it's on the roadmap at all)

- A live room is where evaluation friction gets rescued in real time — the Maya who hits a model-authoring question at 9pm either gets unblocked or churns.
- It's the mechanism that converts users into contributors, and the visible social proof ("487 members") that recruits the next user.
- The MCP ecosystem norm is Discord-shaped; graduating there eventually is natural.

## The empty-room risk (why not now — the evidence is decisive)

- The project has **1 star, 0 forks, 0 issues, 0 external contributors after 13 months** (measured everywhere; e.g. `wave1_bear.md`). A Discord with 4 members and a last message from three weeks ago is *worse* than no Discord: it converts "new project" into "dead project" in one glance — publicly, permanently, at the exact moment strangers are deciding whether to trust it.
- The author's measured availability pattern is burst-mode: "2–4 burst windows" per year, "executive hours," a 9-month dormancy on record (`wave1_portfolio_manager.md`). A chat room is a *synchronous, perishable* commitment — the single worst format for that availability profile. Unanswered questions in Issues look like a backlog; unanswered questions in Discord look like abandonment.
- The panel's repo-trust audit already showed how strangers read weak signals ("the repo page currently signals 'abandoned personal project'" — `wave1_community_architect.md`). Don't build another surface that can broadcast the same signal.

## The interim alternative (day one)

1. **GitHub Discussions** on the repo — asynchronous (fits burst availability), indexed by search engines *and* LLMs (unlike Discord — chat content is invisible to the discovery channel in doc 09), zero new surface to tend, and Q&A accumulates as documentation.
2. **Presence in other people's rooms:** the MCP Discord, dbt Slack, and (post-Postgres) Supabase Discord — be findable where community already exists instead of asking a community to relocate to you. This is also where the rules-of-engagement citizenship (doc 08) already puts you.
3. Every support interaction that repeats twice becomes a docs page (the solo-operator leverage rule).

## The pre-committed launch threshold (decided now, so the moment isn't a mood)

Open a Discord only when **all four** hold:

1. **≥300 GitHub stars** (amplification proof), and
2. **≥3 identifiable external orgs using MiniML in production** (the crux, multiplied — real people with real questions), and
3. **≥10 distinct non-author participants active in Issues/Discussions in the trailing 30 days** (demonstrated demand for conversation, not projected), and
4. **The author has sustained ≥4 hrs/week of community time for 8 consecutive weeks** (demonstrated supply — the binding constraint per the Portfolio Manager).

Realistically this fires late in Phase 2 at the earliest, likely later — which is the correct reading of the evidence, not pessimism.

## Rollout plan when it fires

- **Seed small:** 4 channels max (#help, #show-and-tell, #model-gallery, #dev). Empty channels are the room's empty chairs.
- **Recruit 2 moderator-volunteers from the top external contributors before opening** — if two people won't co-host, the threshold hasn't really fired.
- **Announce in Discussions + release notes; bridge GitHub releases into #dev** automatically so the room has a pulse independent of the author.
- **Office hours:** 30 minutes, biweekly, scheduled — converts the author's burst availability into a predictable ritual instead of an implied always-on promise.
- **Success metric: weekly active posters (target ≥15 by week 12), never member count.**
- **Pre-committed shutdown rule:** if weekly active posters <5 for 12 consecutive weeks, archive the server, post a plain note, fold back to Discussions — a defined outcome, not a quiet fade, matching the plan's kill-criteria ethos (doc 11).
