# 02 — Audience: Conversion Target, Amplification Audience, ICP, Anti-Audience

## The conversion target (who "decides")

Nobody pays — MiniML is MIT and this plan pursues no direct revenue (`wave1_monetization.md`). The "conversion" that matters is an **engineer's decision to put MiniML in an agent's query path.** The tribunal already built this persona and stress-tested her:

> **"Maya Chen, senior full-stack engineer at a 40-person B2B SaaS. Her PM wants a 'chat with your data' panel shipped this sprint (10 working days)… Maya is TypeScript-native, does not want to run another server, and found MiniML by searching 'safe semantic layer for LLM text-to-SQL node.'"** (`wave1_target_user.md`)

Adopt Maya as the canonical ICP. A close secondary: the **founding/staff engineer at an AI-agent startup** adding an analytics or reporting tool to their agent — same language, same infra allergy, higher urgency, more likely to be found in MCP-ecosystem spaces than data-engineering spaces.

### ICP qualifying axes (all must hold for a "qualified" lead)

| Axis | Qualifies | Disqualifies |
|---|---|---|
| Language/runtime | TypeScript/Node (the agent or app is Node) | Python-first team (Boring Semantic Layer already serves them — `wave1_market_cartographer.md`) |
| Task | Actively building LLM→database ("chat with your data," agent analytics tool, embedded reporting) | Generic BI needs, dashboarding |
| Infra tolerance | Won't/can't run another server; wants `npm install` | Happy to run Cube/docker; already on dbt Cloud |
| Warehouse | Snowflake/BigQuery today; Postgres is the expansion bet (`05-database-support.md`) | All-in on Databricks (Genie forecloses it) |
| Governance needs | Wants auditability + determinism; a developer reviews the models | Needs row-level security, caching, SSO, fan-out protection out of the box |
| Stage | Prototype→production of a *feature*, weeks-scale | Enterprise platform selection, RFP-scale |

### Where the conversion target actually spends time

- **GitHub** (topics: `semantic-layer`, `mcp`, `text-to-sql` — note the repo currently has *no topics set*, `wave1_community_architect.md` #1) and **awesome-mcp-servers** / MCP registries (PulseMCP, mcp.so — `wave1_ai_futurist.md`).
- **Hacker News** — the Mar 2025 thread "Building AI agents to query your databases" is demand articulated verbatim (`wave1_market_cartographer.md`, Demand signals).
- **Search and, increasingly, LLM assistants** — the dossier lists the exact queries: "lightweight semantic layer for text-to-SQL," "safe SQL generation for LLM agents," "embeddable metrics layer node.js," "LookML alternative open source YAML" (`dossier.md`). Maya-types now ask Claude/ChatGPT/Cursor these questions; presence in LLM answers is a first-class channel (`09-other-platforms.md`).
- **r/LocalLLaMA** (agent builders, tolerant of show-your-project — `wave1_community_architect.md` #5), the **MCP Discord**, and after Postgres ships, the **Supabase/Neon ecosystems**.
- **Not primarily**: data-engineering Twitter, LinkedIn, or dbt Slack — those are amplification surfaces (below). Do not confuse the two: the people who *share* semantic-layer content (analytics engineers, data leaders) are mostly not the people who will `npm install` a TS library into an agent.

## The amplification audience (who shares, stars, creates social proof)

| Audience | Surface | What they amplify |
|---|---|---|
| MCP ecosystem enthusiasts | awesome-mcp-servers, MCP Discord, PulseMCP/mcp.so, X | New MCP servers, demo GIFs. The listing itself is the endorsement. |
| Data-eng newsletter editors | Data Engineering Weekly (verified: covered Lyft's YAML metric layer, Netflix DataJunction), Ju Data Engineering (covers lightweight/DuckDB-adjacent tooling) — both verified active in `wave1_community_architect.md` #6 | *Ideas*, not projects: "Submit the fan-out doc + security model as the hook, not the project itself." |
| HN crowd | Show HN | Working demos + intellectual honesty. Also the most hostile diligence — they will run the one probe (`wave1_security_auditor.md`: "Discovering this took one probe; a hostile reviewer would close the tab"). |
| Analytics-engineering practitioners | dbt Slack #tools-and-utilities (66k+), Locally Optimistic (~9k, anti-vendor norms), r/dataengineering | War stories and honest engineering write-ups. They star; they rarely embed a Node library. |
| Data/AI leaders (buyer-shaped) | LinkedIn | The author's credibility, not the package. This is the career-capital audience — it converts to *opportunities for Dave*, not users for MiniML. |

**Design implication:** every launch asset needs a conversion-target version (quickstart, template, MCP config snippet) *and* an amplification version (the idea/write-up: fan-out, dead-code confession, benchmark analysis). The Community Architect's verdict that the fan-out warning and security model are "the most credible marketing assets in the repo and they're buried at the bottom" is the operating principle: **the ideas travel; the package rides along.**

## The anti-audience (who this content should deliberately repel)

The repo already proved this works: `fanout.md` opens with "**MiniML does not protect you from join fan-out**" and the panel unanimously cited that honesty as the project's most credible asset. Extend the same posture to people:

1. **Enterprises needing RLS, caching, SSO, fan-out protection, or a serving API.** Say it plainly: *use Cube.* The Rival's counter-pitch (`wave1_rival.md`) is accurate about what MiniML lacks — pre-empt it by agreeing. "If your CISO needs row-level security, MiniML is the wrong tool" costs nothing (they were never going to adopt) and buys trust with everyone else.
2. **All-in Snowflake or Databricks shops.** Cortex Analyst + Semantic View Autopilot and Genie + Metric Views are native, GA, and auto-generate the models (`wave1_market_cartographer.md`, hyperscaler test). Tell them to use the native thing. This defuses the single hardest competitive fact instead of hiding from it.
3. **Python-first teams.** Point them at Boring Semantic Layer by name. (BSL is the direct twin with actual traction; pretending it doesn't exist would be noticed.)
4. **People who want magic NL→SQL with no modeling work.** MiniML's whole thesis is that someone writes the model. "If you won't define your metrics, no semantic layer can save you."
5. **Security-paranoid orgs — until the proof exists.** Until the red-team corpus runs in CI with provenance (`04-prerequisites-and-sequencing.md`), do not court them; the Security Auditor's standard ("does a red-team corpus of 100+ hostile expressions pass in CI with the allowlist actually enforced?") is the bar for re-inviting them.

**How saying this builds credibility:** every semantic-layer vendor claims to be for everyone. A 1,000-LOC library that publishes a "when NOT to use MiniML" page is making a falsifiable, checkable claim about its niche — exactly the posture that earned the only genuine praise the panel gave the project's marketing. This page should exist in `documentation/` and be linked from the README fold.
