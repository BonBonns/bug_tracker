# 11 — Metrics, Pre-Registered Kill Criteria, and the Fallback Plan

## The currency

The business goal (doc 01) is a decisive answer to the crux plus career capital. So the metrics that count are **external adoption events** and **career-capital events** — not impressions, followers, or video views (those are diagnostics for channel allocation only). Stars and downloads appear *only* because the tribunal pre-registered them as adoption proxies; they never override the production-user gate.

**"No renegotiating the thresholds after the fact"** (`VERDICT.md` §6) is the operating rule for everything below. Week-12's X post (doc 07) publishes these criteria *before* the measurement — making a quiet fade socially impossible, by design.

## Instrumentation (build in Phase 0 — attribution decays if added later)

1. **Weekly snapshot script** (cron; ~2 hrs to build once): GitHub API (stars, forks, issues/PRs by non-author accounts, traffic referrers — GitHub keeps only 14 days, so weekly capture is mandatory) + npm downloads API → one CSV in the repo. This is the ledger every checkpoint reads from — the same APIs the tribunal itself used.
2. **Per-channel short links** on the owned domain (`/hn`, `/yt`, `/x`, `/rdt`, `/nl`, `/li`) → qualified-visit attribution by channel.
3. **Issue template field:** "How did you find MiniML?" — the only attribution that survives to the adoption events that matter.
4. **External-org tracker:** a private list of identifiable orgs trialing/deploying (from issues, outreach replies, Discussions). This is the crux ledger.
5. Monthly **LLM-presence probe** (5 canned prompts, doc 09) — logged, not gated on.

## Checkpoint 1 — Day 90 after launch (the tribunal's gate, verbatim)

From `VERDICT.md` §6:

| # | Criterion |
|---|---|
| 1 | ≥ 75 GitHub stars from non-author accounts |
| 2 | ≥ 500 weekly npm downloads **sustained** (not a launch-day spike) |
| 3 | ≥ 3 inbound issues/PRs from strangers |
| 4 | ≥ 1 identifiable external org trialing the MCP server |

**Decision rule:** ≥3 of 4 → continue into Phase 2 (escalate toward DOUBLE DOWN). ≤1 of 4 → **archive the ambition** (fallback below). Exactly 2 of 4 → free-channels-only holding pattern (X + Discussions + answering issues; no video production, no Postgres work), re-measure once at day 135; if still <3, archive — one extension, pre-sized, never repeated.

**Publish the result either way** — a short post with the actual numbers. On a miss, that post *is* career-capital content ("I pre-registered kill criteria for my own project and honored them" is a rarer and more hireable artifact than a modest success).

## Checkpoint 2 — Month 6

Measured in the goal's currency; the production-user gate is binding:

| Criterion | Threshold | Why this number |
|---|---|---|
| **External production orgs** | ≥ 1 (the crux, now in production not trial) | The question every panelist said would change their mind (Bear, Rival, Monetization) |
| Sustained weekly npm downloads | ≥ 1,000 | The Cartographer's own re-visit threshold ("~50 stars and ~1,000 weekly downloads… would prove the sliver actually converts") |
| External contribution | ≥ 1 merged non-author PR | First proof the DCO/CONTRIBUTING machinery works |
| Career-capital events | ≥ 2 (talk/podcast invite, consulting inquiry, credible inbound role, newsletter feature) | The path that pays (`wave1_monetization.md` Path 1) needs its own scoreboard |

**Decision rule:** production-orgs = 0 → stop Phase 2 spend immediately (even if downloads/stars pass — that's amplification without conversion, the exact vanity trap); enter maintenance mode + fallback. Production-orgs ≥ 1 but others soft → continue, but reallocate hours from weakest-attributed channel to direct outreach (doc 12).

## Checkpoint 3 — Month 12

| Criterion | Threshold |
|---|---|
| External production orgs | ≥ 3 |
| Sustained weekly downloads | ≥ 2,500 |
| Community | ≥ 5 external contributors ever merged; Discussions self-answering (≥25% of questions answered by non-author) |
| Ecosystem recognition | ≥ 1 of: newsletter feature, OSI-adjacent citation, conference talk delivered, a competitor names it in a comparison |
| Career-capital ledger | ≥ 2 concrete realized opportunities (engagement, offer, paid talk) — the Monetization brief's $10–40k/yr leverage claim, audited against reality |

**Decision rule:** pass → this stops being a side project experiment and deserves a fresh strategy round (the 2027 question: Wayvia sponsorship formalized? open-core test? — "a single external paying production user flips open-core from 'kill' to 'test'"). Partial → continue only the channels with attributed conversions; kill the rest without ceremony. Fail on production-orgs → same fallback as day 90; twelve months of evidence outranks any remaining hope.

## The pre-committed fallback: "archive the ambition, not the code"

Stopping is a defined outcome with a playbook, not a fade (`VERDICT.md`: "This pre-commitment is the antidote to sunk-cost drift"):

1. **Keep the code.** It's near-free, employer-subsidized, dogfooded — "archiving frees ≈0 hours while destroying a live relicensing option and a real career-capital artifact" (`VERDICT.md`, Why not ARCHIVE). npm stays maintained for Wayvia's use.
2. **Stop all public-adoption spend** — no more launches, videos, or campaign posts. The Bear's target was always "the campaign, not the code" (`wave2_bear_rebuttal.md`).
3. **Post the honest status note** — pin it: what was tried, the pre-registered numbers, the verdict. (The anti-pattern is Vanna-style ambiguity; the model is the clean pre-commitment this plan started with.)
4. **Redirect the freed hours to author-brand writing** — the accuracy/governance/fan-out content keeps paying career capital with the project in maintenance mode; "market the author rather than the package" was the #1-ranked path all along (`wave1_monetization.md`).
5. **Keep the option.** Sole-copyright status (protected by the DCO decision in Phase 0) means a future re-activation — a Wayvia sponsorship, an OSI turn, a BSL-style opening in TS — remains a unilateral choice.

## Vanity-metric ban (explicit)

Not decision inputs, ever: X followers/impressions, YouTube subscribers/views, LinkedIn reactions, HN points, Discord member count, cumulative (vs. sustained) downloads, launch-day spikes. Each may be *diagnosed* (e.g., video views per qualified click decide the doc-06 channel-kill rule) but none can satisfy a checkpoint. The tribunal's own method is the standard: count only what an API can prove and a stranger did.
