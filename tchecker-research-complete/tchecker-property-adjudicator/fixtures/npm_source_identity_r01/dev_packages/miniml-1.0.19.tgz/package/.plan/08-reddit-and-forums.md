# 08 — Reddit and Practitioner Forums: A Value-First Playbook

## Role in the funnel

Reddit/Slack communities are where the ICP describes the problem in their own words — and where self-promotion is a bannable offense. The playbook is the Community Architect's, whose plan explicitly passed its own disqualification check: "this plan is not 'post it and hope' — items 3–6 each carry a channel-specific framing" (`wave1_community_architect.md`).

## Rules of engagement (all communities, non-negotiable)

1. **Two weeks of citizenship before any post that mentions MiniML.** Answer other people's questions about text-to-SQL, semantic layers, MCP config. The account's history is the first thing skeptics check.
2. **Always disclose authorship** ("I built this; flame away") — HN and r/dataengineering reward it and destroy the alternative.
3. **Lead with the lesson, not the tool.** Every post must be worth reading by someone who will never install MiniML.
4. **Stay online 6 hours after posting; answer everything within 24h.** An unanswered top comment is a public verdict.
5. **Never post the same content to two communities in the same week**; each gets its own framing.
6. **Concede fast.** When someone says "Cube does this better" — if it's true for their case, say so. The anti-audience posture (`02-audience-and-icp.md`) is the whole differentiation.

## What disqualifies a post (pre-committed)

- It's a feature announcement without a transferable lesson.
- The claim in the title can't be reproduced by a stranger in 10 minutes (the Maya standard: the Quick Start must run verbatim first — `wave1_target_user.md`).
- You can't be available for the following 6 hours.
- The honest answer to "why not just use X?" isn't yet written down somewhere linkable.
- The community was never engaged before the post (rule 1 unfulfilled).

## Communities, in order, with framings

### Launch window (Phase 1, weeks 9–10)

1. **dbt Community Slack — #tools-and-utilities** (66k+ members, verified — `wave1_community_architect.md` #3). Framing verbatim from the brief: *"the semantic layer for people who found MetricFlow too heavy to embed."* Short post, demo GIF, invite critique of the model format.
2. **MCP Discord / show-and-tell surfaces.** Demo-clip post: the Claude Desktop loop. This audience evaluates in seconds and shares registries; the working demo *is* the post.
3. **r/dataengineering** — the designated framing: a lessons-learned write-up, not a launch: *"I stopped letting the LLM write SQL; here's the ~1,000-line library I wrote instead"* (`wave1_community_architect.md` #5). Body covers: the accuracy evidence, the vocabulary-not-freeform design, the fan-out caveat (leading with the limitation is the credibility move), link last.
4. **r/LocalLLaMA** — show-your-project post, agent-builder angle: "A governed SQL vocabulary for your local agent — deterministic compile, no cloud, MIT." This community is the closest Reddit proxy for the actual ICP.

### Second wave (weeks 11–13)

5. **Locally Optimistic Slack** (~9k analytics leaders, invite-gated, **explicit anti-vendor norms**). Per the brief: "Do NOT pitch; ask a question ('how are you constraining LLM SQL generation?') and let the repo appear in the answer" — and only if it genuinely fits the conversation.
6. **r/BusinessIntelligence** — the "chat with your data" buyer-adjacent crowd; frame around the *decision* ("what we learned comparing semantic-layer options for an embedded AI analytics feature"), linking the steelmanned alternatives.md.

### Phase 2 additions (conditional)

7. **Supabase Discord + r/Supabase, Neon community** — only after the Postgres dialect ships (month 5); framing: "chat with your Postgres data via Claude, safely — template inside." This is the highest-conversion forum play in the whole plan because ICP density is maximal.
8. **r/node / r/typescript** — one tutorial-shaped post each, keyed to V3/V12 (the Node tutorial and MCP-server-in-TS video).

### Explicitly avoided

- **r/programming** — "name collision with the ML teaching language invites derailment" (`wave1_community_architect.md` #5). The thread becomes about MiniML-the-lambda-calculus.
- **r/MachineLearning, r/datascience** — wrong audience (researchers/analysts, not embedders).
- Any community where rule 1 can't be honored in time — better unposted than parachuted.

## Cadence and effort

Launch window: ~4 posts over 2 weeks (heavy response load — budget 6–8 hrs those weeks). Steady state Phase 2: **≤1 MiniML-mentioning post per community per quarter**, continuous low-level citizenship (~30 min/week). Forums are a launch amplifier and a listening post, not a drumbeat channel — over-posting here is how projects get quietly labeled spam.

**Listening function:** every thread where someone describes the governed-LLM-SQL problem goes into the outreach list (`12-non-content-paths.md`). The Mar 2025 HN thread already seeds it.
