# 06 — YouTube: 12-Month Video-by-Video Plan

## Role in the funnel

Two jobs, in priority order: (1) **searchable evergreen** — own the long-tail queries a Maya types the week she gets the "chat with your data" ticket; (2) **trust** — for a project whose credibility problem is "advertised-but-not-shipped" (`wave2_bull_rebuttal.md`), video is the medium where you can't fake a working demo. Every video's CTA is the same conversion surface: the README's MCP quickstart anchor, via a `miniml.dev/yt` short link (attribution).

## Cadence a busy person can actually sustain — and the honesty check

The Portfolio Manager's evidence says the default outcome is abandonment: the author's discretionary output pattern is "2–4 burst windows totaling 15–30 commits" per year, hours are "executive hours, not IC hours," and the predicted behavior absent structure is "no MCP server unless Wayvia needs one" (`wave1_portfolio_manager.md`). **A weekly cadence is fantasy; even monthly is a bet.** The plan therefore:

- **Phase 1 (months 1–3): 3 videos total**, produced in the weeks 6–8 asset window *alongside* the hero GIF (same recordings, different cuts). No ongoing commitment yet.
- **Phase 2 (months 4–12, conditional on the day-90 gate): 1 video/month + 4 flagship**, ~16 videos year one.
- **Effort:** flagship 6–8 hrs; standard tutorial 4–5 hrs; downgrade format 1.5–2 hrs. Phase 2 average ≈ 1–1.5 hrs/week amortized.

### Structural defenses against "N videos then silence" (the #1 risk)

1. **Banked buffer:** V2 and V3 are fully produced before V1 publishes. The channel never goes live with zero runway. In Phase 2, maintain a 1-video buffer at all times; if the buffer is empty, the next monthly slot produces buffer, not a publish.
2. **Batch production:** one recording day per quarter (a Saturday) produces 3 videos' raw material. Scripts are the blog twins (written first — see `09-other-platforms.md`), so recording is reading + demoing, not creating.
3. **Pre-authorized downgrade rule (decided now, not in the moment of failure):** if a month's video isn't published by the 21st, ship the downgrade format instead — a 3–5-minute asciicast/screen capture with voiceover, no editing, no thumbnail art. If two consecutive months downgrade, the official cadence becomes bimonthly — update the channel description, no apology video, no "I'm back" video. A smaller channel that's alive beats a bigger one that visibly died.
4. **Evergreen by construction:** no dates in titles/thumbnails, no "news" videos, no version-number titles. Every video must still be correct in 18 months or be re-recordable from its script in an hour.

## The schedule (titles written as search queries)

**Legend:** [F] flagship/shareable · [E] searchable/evergreen · each row names the artifact the video ships (VERDICT §3's growth loop: artifacts are forkable; forks recruit).

### Phase 1 — launch support (committed)

| # | Month | Title (as search query) | Format | Artifact shipped | Type |
|---|---|---|---|---|---|
| V1 | M2 (launch week) | **Stop letting your LLM write SQL — a governed text-to-SQL demo with MCP** | 6-min hero demo: Claude Desktop → MiniML MCP server → "revenue by plan tier last month" → governed SQL → result (the VERDICT's "single hero demo," verbatim) | The MCP quickstart + demo model repo | F |
| V2 | M2 | **Why text to SQL fails in production (and what actually fixes it)** | 8-min talking-head + slides: dbt 98–100% vs 84–90%, Spider 2.0's 36% enterprise ceiling, "confident wrong numbers" vs refusals (`wave1_ai_futurist.md` evidence base) | Blog twin = the launch post | F |
| V3 | M3 | **Build a chat-with-your-data feature in Node.js (full tutorial)** | 15–20-min hands-on: YAML model → renderQuery → agent loop | Companion example repo | E |

### Phase 2 — conditional on the day-90 gate

| # | Month | Title (as search query) | Format | Artifact | Type |
|---|---|---|---|---|---|
| V4 | M4 | **What is a semantic layer? Dimensions, measures, and why AI agents need one** | 7-min explainer (top-of-funnel evergreen; owns the education query) | Glossary page on docs site | E |
| V5 | M4 | **How to connect Claude Desktop to your database safely (MCP server tutorial)** | 10-min tutorial — deliberately broader than MiniML; captures the MCP-config search intent | Copy-paste MCP config gallery | E |
| V6 | M5 | **Postgres text-to-SQL with a semantic layer — no server required** | 10-min: the Postgres dialect launch video (second launch moment, `05-database-support.md`) | Postgres + Supabase template models | F |
| V7 | M5 | **Model your Stripe data in YAML for AI queries (semantic model tutorial)** | 12-min template walkthrough | Stripe gallery template | E |
| V8 | M6 | **My SQL safety layer had a bug for 13 months — red-teaming my own validator** | 10-min engineering confession: the dead-code AST validator, the fix, the red-team corpus, "tests must assert the control runs" | The corpus + CI write-up | F |
| V9 | M6 | **DuckDB + a semantic layer: a local analytics agent in 10 minutes** | 10-min zero-setup tutorial (DuckDB dialect launch) | DuckDB starter repo | E |
| V10 | M7 | **Cube vs dbt Semantic Layer vs building your own: which do you actually need?** | 9-min honest comparison — the anti-audience video; sends enterprise viewers to Cube *by name* (`02-audience-and-icp.md`) | alternatives.md refresh | E |
| V11 | M8 | **Join fan-out: why your revenue numbers silently double (SQL joins explained)** | 8-min: `fanout.md` as video — the panel's "most credible marketing asset" in its most shareable form | fanout.md + grain-modeling examples | F |
| V12 | M8 | **How to build an MCP server in TypeScript (lessons learned)** | 12-min tutorial for the MCP-builder audience (amplification crowd) | Annotated server source walkthrough | E |
| V13 | M9 | **Writing model metadata your LLM will actually follow (model cards for data)** | 8-min on the `info`/model-card generator — the "genuinely agent-relevant asset" (`wave1_principal_engineer.md`) | Model-card cookbook page | E |
| V14 | M10 | **Date ranges, granularity, and timezones: the hard parts of analytics SQL** | 10-min deep-dive (the hardest problems the project solves — and where its bugs lived; own the topic honestly) | Date-handling docs page | E |
| V15 | M11 | **Multi-tenant chat with your data: scoping what the AI can see** | 10-min on tags/model-access patterns (ships with the TASKS.md tags feature if built; otherwise patterns-only) | Multi-tenant example | E |
| V16 | M12 | **One year of building an open-source semantic layer: real numbers, mistakes, verdict** | 10-min transparency retrospective keyed to the month-12 checkpoint — publishes the actual metrics against the pre-registered criteria | The metrics ledger itself | F |

## Production notes

- **Progression check** (per the brief's requirement): V1–V5 basic/introductory → V6–V10 real-world integration → V11–V15 the hardest problems (fan-out, date semantics, multi-tenancy, LLM-following metadata) → V16 accountability.
- Screen-capture + voiceover for everything except V2/V10 (slides). No face-cam requirement — lowers the production bar, raises survival odds.
- Every video's script is written as the blog post first; publish the post the same day (SEO twin, and the script bank is the abandonment insurance).
- Thumbnails: one reusable template (terminal screenshot + 4-word overlay). Do not let thumbnail perfectionism become the abandonment vector.
- **Kill rule for the channel itself:** if at month 9 total channel-attributed qualified visits (short-link clicks) are <5% of all attributed visits, stop producing video and keep only the blog twins — the pre-committed acknowledgment that for this ICP, text may simply outperform video.
