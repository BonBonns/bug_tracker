# 12 — Faster Non-Content Paths to the Same Goal (and How Content Multiplies Them)

Content is the slow, compounding path. Three non-content moves have higher expected value per hour toward the crux (one external production org), and one of them outranks everything else in this plan.

## 1. Wayvia formal sponsorship — the single highest-leverage move available

The Portfolio Manager's one question that would change their mind: "Will Wayvia formally adopt miniml as the semantic layer inside a customer-facing conversational-analytics product… because that converts his employer from a passive subsidizer into an active sponsor, funds the MCP server and multi-dialect roadmap on company time, **and is the only mechanism visible in the evidence that gets this project distribution and maintenance hours it will never get from nights and weekends**" (`wave1_portfolio_manager.md`).

- **The ask:** an internal pitch — MiniML already powers Wayvia's conversational analytics (Wayvia's own flagship launch is *Wayvia MCP*, per License Counsel §3 — the strategic alignment is literal); formal adoption + open-source sponsorship buys Wayvia an engineering-brand halo and de-risks a dependency it already has.
- **What it solves at a stroke:** the hours constraint (the plan's #1 risk), the IP cloud (a written agreement is the natural vehicle for the ownership waiver Phase 0 requires), and the social-proof cold start ("Used in production at Wayvia" is the one line of the README no competitor can copy).
- **Cost:** one internal document and one conversation. Do this in Phase 0, in parallel with the legal question — they're the same meeting.
- **Honesty note:** Wayvia is *not* an external org for kill-criteria purposes; the crux still needs a stranger.

## 2. Direct outreach — concierge onboarding for 25 named targets

One production user acquired by hand beats 30,000 impressions (doc 01's math). Starting week 10 (post-launch), ~2 hrs/week:

- **The list:** commenters in the Mar 2025 HN thread who described MiniML's exact architecture in their own words (`wave1_market_cartographer.md`, Demand signals — a pre-qualified roster); TS/MCP tool builders visible in awesome-mcp-servers and registries; companies with "chat with your data" job posts or launch announcements; anyone who stars/forks post-launch (warm by definition); (post-Postgres) active Supabase/Neon community builders.
- **The offer, verbatim-simple:** "I'll write your first model with you on a 30-minute call, free, and fix whatever breaks within a week." At the project's stage, white-glove is the *only* honest onboarding — and each call produces the two things the plan is starved of: a named external trial (kill-criterion #4) and ground-truth friction data (Maya's brief, but live).
- **Cap and kill:** 25 targets, personalized (never templated blast — this audience smells it), stop after 2 batches if reply rate <10%.

## 3. Ecosystem partnerships (cheap, asymmetric)

- **OSI participation** — the Contrarian's blind spot: MiniML's genuinely best asset may be the *notation* ("notations win by being copied, not installed" — `wave2_contrarian.md`). Joining Open Semantic Interchange discussions and shipping an OSI import/export costs little, hedges format-commoditization (`wave1_ai_futurist.md`), and puts the author in the room where the category's standard is being written — pure career capital even if MiniML-the-package loses. The Cartographer's caveat stands (a solo notation "isn't in the room" without distribution), which is why this is a Phase 2 move that rides on the launch, not a substitute for it.
- **Supabase/Neon/MotherDuck ecosystem programs** (post-Postgres/DuckDB): these companies actively amplify community integrations — a listed integration + one co-marketed template is distribution MiniML can't buy alone.
- **Anthropic/MCP ecosystem:** registry listings (doc 09) plus showing up in MCP community showcases; the MCP server makes MiniML a citizen of someone else's fast-growing distribution system — the entire amplification thesis of `wave1_ai_futurist.md`.

## 4. Repricing existing customers — N/A, and the honest note

The brief asks about it; there are no customers to reprice (`wave1_monetization.md`: direct revenue "~2/100"). The nearest analog *is* move #1 — converting the one de-facto customer (Wayvia) from free rider to sponsor.

## How content multiplies these (not replaces them)

- The cold outreach message with the 45-second hero clip attached is a different message from a text pitch; the demo does the persuading.
- Every newsletter feature or HN thread makes the *next* outreach warm ("saw this on DEW last week…").
- The pre-registered-criteria transparency posts are what make partners and sponsors comfortable — nobody co-markets with a project that might quietly vanish; this one has published rules for how it won't.
- Reverse flow: every outreach call generates the most credible content there is (real friction, real fixes, real user stories — with permission).
