export declare function constructCurrentTimeOffsetExpression(dialect: string, date_offset: number, date_part: string, is_date?: boolean): string;
export declare function constructDateRangeExpression(dialect: string, date_field: string, date_offset: number, date_part: string, include_today?: boolean, is_date?: boolean): string;
export declare function constructDateTruncExpression(dialect: string, date_expr: string, date_granularity: string): string;
export declare function constructDateAddExpression(dialect: string, expression: string, num: number, date_part: string): string;
export declare function constructDateSubExpression(dialect: string, date_field: string, num: number, date_part: string): string;
export declare function constructTodayAtMidnightExpression(dialect: string, is_date?: boolean): string;
export declare function normalizeQuotesForBigQuery(expression?: string): string | undefined;
